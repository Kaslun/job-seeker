// App entry — wires the design canvas + tweaks panel.

const App = () => {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);

  // Apply tweaks as CSS custom properties on the body, plus density/wobble/anno classes.
  React.useEffect(() => {
    const b = document.body;
    b.style.setProperty("--accent", t.accent);
    b.style.setProperty("--ink", t.ink);
    b.style.setProperty("--paper", t.paper);
    b.classList.toggle("no-anno", !t.showAnnotations);
    b.classList.remove("density-cozy", "density-compact");
    b.classList.add("density-" + (t.density || "cozy"));
    b.classList.toggle("wobble", !!t.wobble);
  }, [t]);

  // Each section is at standard desktop wireframe size.
  const W = 760, H = 580, MW = 320, MH = 600;

  return (
    <>
      <div className="cover">
        <div className="row" style={{ gap: 18, alignItems: "center", marginBottom: 14, flexWrap: "wrap" }}>
          <Logo size={32} />
          <span className="adhd-sticker">made for adhd brains</span>
        </div>
        <h1>questboard — game design jobs, without the doom-scroll.</h1>
        <p className="muted">
          Wireframes for a job board for designers breaking into the international games industry.
          Two principles drive every screen: <span className="hl"><b>one decision at a time</b></span> and
          <span className="hl"> <b>finishable, not infinite</b></span>. Like &amp; dislike are the only verbs —
          dismiss removes a job from the database forever, so the pile only ever shrinks.
          Open any artboard fullscreen with the ⤢ icon. Use the Tweaks panel (top toolbar) to
          recolor, hide annotations, or jump between sections.
        </p>
      </div>

      <DesignCanvas style={{ height: "calc(100vh - 220px)" }}>
        <DCSection id="feed" title="1 · Job feed" subtitle="four directions for the core browse experience">
          <DCArtboard id="feed-list" label="A · Classic list" width={W} height={H}><FeedList /></DCArtboard>
          <DCArtboard id="feed-swipe" label="B · One-at-a-time" width={W} height={H}><FeedSwipe /></DCArtboard>
          <DCArtboard id="feed-grid" label="C · Visual grid" width={W} height={H}><FeedGrid /></DCArtboard>
          <DCArtboard id="feed-focus" label="D · Today's 5 (focus)" width={W} height={H}><FeedFocus /></DCArtboard>
        </DCSection>

        <DCSection id="detail" title="2 · Job detail" subtitle="open a posting — read, decide, apply">
          <DCArtboard id="detail-classic" label="A · Two-column" width={W} height={H}><DetailClassic /></DCArtboard>
          <DCArtboard id="detail-tldr" label="B · TL;DR" width={W} height={H}><DetailTLDR /></DCArtboard>
          <DCArtboard id="detail-story" label="C · Long-form" width={W} height={H}><DetailStory /></DCArtboard>
        </DCSection>

        <DCSection id="onboard" title="3 · Onboarding" subtitle="set up engine / genre / location preferences">
          <DCArtboard id="onb-wizard" label="A · Wizard" width={W} height={H}><OnboardWizard /></DCArtboard>
          <DCArtboard id="onb-oneshot" label="B · One-shot form" width={W} height={H}><OnboardOneShot /></DCArtboard>
          <DCArtboard id="onb-chat" label="C · Conversational" width={W} height={H}><OnboardChat /></DCArtboard>
        </DCSection>

        <DCSection id="track" title="4 · Saved &amp; applications" subtitle="the post-decision life of a job">
          <DCArtboard id="trk-saved" label="A · Saved columns" width={W} height={H}><SavedColumns /></DCArtboard>
          <DCArtboard id="trk-tracker" label="B · Applications tracker" width={W} height={H}><Tracker /></DCArtboard>
          <DCArtboard id="trk-detail" label="C · Single application" width={W} height={H}><ApplicationDetail /></DCArtboard>
        </DCSection>

        <DCSection id="mobile" title="5 · Mobile" subtitle="thumb-zone variants of the feed">
          <DCArtboard id="m-swipe" label="A · Swipe" width={MW} height={MH}><MobileSwipe /></DCArtboard>
          <DCArtboard id="m-list" label="B · List" width={MW} height={MH}><MobileList /></DCArtboard>
          <DCArtboard id="m-focus" label="C · Today's 5" width={MW} height={MH}><MobileFocus /></DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Vibe">
          <TweakColor label="Accent" value={t.accent} options={["#ffe66d", "#ff7a59", "#7ddff7", "#c8b6ff", "#ffffff"]} onChange={v => setTweak("accent", v)} />
          <TweakColor label="Ink" value={t.ink} options={["#1c1a17", "#0f3460", "#3d2c2e", "#1a3d2e"]} onChange={v => setTweak("ink", v)} />
          <TweakColor label="Paper" value={t.paper} options={["#faf8f1", "#f3efe3", "#ffffff", "#fff6e3"]} onChange={v => setTweak("paper", v)} />
          <TweakToggle label="Hand-drawn wobble" value={t.wobble} onChange={v => setTweak("wobble", v)} />
        </TweakSection>
        <TweakSection label="Annotations">
          <TweakToggle label="Show designer notes" value={t.showAnnotations} onChange={v => setTweak("showAnnotations", v)} />
          <TweakRadio label="Density" value={t.density} options={[{ value: "cozy", label: "cozy" }, { value: "compact", label: "compact" }]} onChange={v => setTweak("density", v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
