// hifi-app.jsx — assembles all hi-fi screens onto the design canvas

const { useState } = React;

// Default tweaks
const DEFAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "accent": "#ffd84d",
  "paper": "#faf8f1",
  "ink": "#15130f",
  "fontDisplay": "Bricolage Grotesque",
  "fontBody": "Geist",
  "showAnnotations": false,
  "density": "comfy"
}/*EDITMODE-END*/;

const ACCENT_OPTIONS = [
  ["#ffd84d", "#15130f", "#faf8f1"],   // yellow / ink / paper (default)
  ["#ff7a4d", "#1a1410", "#fbf6ee"],   // ember
  ["#a8c66c", "#14201a", "#f4f6ec"],   // moss
  ["#7eaef7", "#0e1a2a", "#f1f5fb"],   // ice
];

const FrameLabel = ({ children }) => (
  <div className="mono dim" style={{ fontSize: 11, letterSpacing: ".08em", textTransform: "uppercase", marginBottom: 4 }}>{children}</div>
);

const Frame = ({ width = 1280, height = 800, children, mobile = false }) => (
  <div style={{
    width, height, background: "var(--paper)",
    borderRadius: 14, border: "1px solid var(--paper-3)",
    overflow: "hidden", position: "relative",
    boxShadow: "0 1px 0 rgba(0,0,0,0.04), 0 8px 30px -10px rgba(0,0,0,0.12)",
    display: mobile ? "flex" : "block", alignItems: "center", justifyContent: "center",
  }}>{children}</div>
);

const App = () => {
  const [tweaks, setTweak] = useTweaks(DEFAULT_TWEAKS);

  // Apply tweaks to CSS variables on root
  React.useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent", tweaks.accent);
    r.style.setProperty("--paper", tweaks.paper);
    r.style.setProperty("--ink", tweaks.ink);
    r.style.setProperty("--f-display", `'${tweaks.fontDisplay}', serif`);
    r.style.setProperty("--f-body", `'${tweaks.fontBody}', system-ui, sans-serif`);
    document.body.classList.toggle("no-anno", !tweaks.showAnnotations);
  }, [tweaks]);

  return (
    <>
      <DesignCanvas>
        {/* Cover */}
        <DCSection id="cover" title="questboard" subtitle="hi-fi pass · designed for the focus-fragile">
          <DCArtboard id="cover" label="Cover" width={1280} height={780}>
            <div style={{ height: "100%", padding: "70px 70px 56px", display: "flex", flexDirection: "column", justifyContent: "space-between", gap: 40, background: "var(--paper)", position: "relative" }}>
              <div className="row between">
                <Logo size="lg" />
                <div className="row gap-3">
                  <span className="chip">v3 · hi-fi</span>
                  <span className="chip chip-accent">designed for ADHD</span>
                </div>
              </div>
              <div>
                <div className="eyebrow" style={{ marginBottom: 16 }}>A JOB BOARD FOR INTERNATIONAL GAME DESIGNERS</div>
                <h1 style={{ fontFamily: "var(--f-display)", fontSize: 88, lineHeight: 0.95, letterSpacing: "-0.03em", margin: "0 0 22px", maxWidth: 1100, fontWeight: 700 }}>
                  Five jobs.<br />Five decisions.<br /><span className="draw-u">You're done</span><br />for the day.
                </h1>
                <p className="body muted" style={{ fontSize: 19, maxWidth: 720, margin: 0 }}>
                  Most boards punish you for not scrolling forever. questboard makes job hunting <em>finishable</em> — five swipes, then it locks the feed and tells you to go live your life.
                </p>
              </div>
              <div className="row gap-4 wrap">
                {[
                  ["⊙ One decision at a time", "Like or dismiss. No 'maybe' pile."],
                  ["⌖ Same answers, every time", "Salary · location · stack · timeline · who you'd work with."],
                  ["✓ Finishable, not infinite", "Daily 5, not endless feed."],
                  ["⛬ Stage-aware tracker", "Always know what's next."],
                ].map((p, i) => (
                  <div key={i} style={{ flex: "1 1 240px", padding: "16px 0", borderTop: "1.5px solid var(--ink)" }}>
                    <div className="h3" style={{ fontSize: 16, marginBottom: 4 }}>{p[0]}</div>
                    <div className="muted" style={{ fontSize: 13 }}>{p[1]}</div>
                  </div>
                ))}
              </div>
            </div>
          </DCArtboard>
        </DCSection>

        {/* Feed */}
        <DCSection id="feed" title="01 · Feed" subtitle="Daily 5, swipe-to-decide. ←/→ on keyboard works.">
          <DCArtboard id="feed-desktop" label="Feed · desktop · interactive" width={1280} height={900}>
            <HiFeed />
          </DCArtboard>
          <DCArtboard id="feed-mobile" label="Feed · mobile · swipe stack" width={420} height={820}>
            <Frame width={420} height={820} mobile>
              <HiMobile />
            </Frame>
          </DCArtboard>
        </DCSection>

        {/* Job detail */}
        <DCSection id="detail" title="02 · Job detail" subtitle="Two-column · same 5 questions answered for every job.">
          <DCArtboard id="detail-desktop" label="Job detail · desktop" width={1280} height={1280}>
            <HiDetail />
          </DCArtboard>
        </DCSection>

        {/* Onboarding */}
        <DCSection id="onboard" title="03 · Onboarding" subtitle="Wizard · 4 steps · skippable · ADHD-friendly.">
          <DCArtboard id="onboard-step" label="Step 2 of 4 · engines" width={1280} height={760}>
            <HiOnboard />
          </DCArtboard>
        </DCSection>

        {/* Tracker */}
        <DCSection id="tracker" title="04 · Tracker" subtitle="Where every application is. Always.">
          <DCArtboard id="tracker-overview" label="Tracker · overview" width={1280} height={900}>
            <HiTracker />
          </DCArtboard>
          <DCArtboard id="tracker-app" label="Single application · interview booked" width={1280} height={1100}>
            <HiApplication />
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Palette">
          <TweakColor
            label="Theme"
            options={ACCENT_OPTIONS}
            value={[tweaks.accent, tweaks.ink, tweaks.paper]}
            onChange={([accent, ink, paper]) => setTweak({ accent, ink, paper })}
          />
        </TweakSection>
        <TweakSection title="Typography">
          <TweakSelect
            label="Display"
            options={["Bricolage Grotesque", "Fraunces", "Instrument Serif", "Space Grotesk", "Geist"]}
            value={tweaks.fontDisplay}
            onChange={(v) => setTweak("fontDisplay", v)}
          />
          <TweakSelect
            label="Body"
            options={["Geist", "Inter", "IBM Plex Sans", "Bricolage Grotesque"]}
            value={tweaks.fontBody}
            onChange={(v) => setTweak("fontBody", v)}
          />
        </TweakSection>
        <TweakSection title="Display">
          <TweakToggle label="Show annotations" value={tweaks.showAnnotations} onChange={(v) => setTweak("showAnnotations", v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
