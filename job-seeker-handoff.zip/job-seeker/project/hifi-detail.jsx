// Job detail screen — two-column classic, hi-fi

const HiDetail = () => {
  const job = JOBS[0]; // Aurora Systems Designer
  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--paper)" }} className="no-scrollbar">
      <TopNav active="Feed" />
      <div style={{ padding: "24px 60px 60px", maxWidth: 1080, margin: "0 auto" }}>
        <div className="row between" style={{ marginBottom: 18 }}>
          <span className="row gap-2 mono dim" style={{ fontSize: 12, cursor: "pointer" }}>← back to feed</span>
          <span className="mono dim">2 of 5 today</span>
        </div>

        {/* Hero */}
        <CoverArt studio={job.studio} title={job.game} style={{ width: "100%", aspectRatio: "21 / 9", marginBottom: 20 }} />

        <div className="row between start" style={{ marginBottom: 18 }}>
          <div className="grow">
            <div className="row gap-3" style={{ marginBottom: 8 }}>
              <span className="eyebrow">{job.studioName}</span>
              <span className="chip chip-sage" style={{ fontSize: 11 }}>● Hiring · responds in ~3d</span>
              <span className="chip chip-outline" style={{ fontSize: 11 }}>{job.posted}</span>
            </div>
            <h1 className="h1">{job.title}.</h1>
            <div className="row wrap gap-4" style={{ marginTop: 12, fontSize: 14, color: "var(--ink-2)" }}>
              <span className="row gap-2">{ICONS.pin()} {job.loc}</span>
              <span className="row gap-2">{ICONS.cash()} {job.pay}</span>
              <span className="row gap-2">{ICONS.cal()} Full-time</span>
              <span className="row gap-2">{ICONS.globe()} Visa &amp; relocation</span>
            </div>
          </div>
          <div className="col" style={{ alignItems: "flex-end", gap: 12, flex: "0 0 auto" }}>
            <button className="apply-btn">Apply now {ICONS.arrow()} <span className="kbd">⌘↵</span></button>
            <div className="row gap-2">
              <button className="btn btn-icon-sm" title="Pass">{ICONS.x()}</button>
              <button className="btn btn-icon-sm" title="Park">{ICONS.bookmark()}</button>
              <button className="btn btn-icon-sm btn-primary" title="Save">{ICONS.heart(true)}</button>
            </div>
          </div>
        </div>

        <TagRow tags={[...job.tags, "No-crunch verified"]} variant="accent-first" />

        <hr className="divider" style={{ margin: "28px 0" }} />

        {/* Two columns */}
        <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 36 }}>
          <div className="col" style={{ gap: 28 }}>
            <section>
              <h2 className="h2" style={{ marginBottom: 12 }}>The role</h2>
              <p className="body" style={{ color: "var(--ink-2)" }}>
                We're tuning the systems for <strong>Hollow Ridge II</strong> — an open-world RPG with a deep economy, branching faction politics, and emergent combat.
                You'll own the math: progression curves, loot tables, faction reputation, and the live-ops cadence after launch.
              </p>
              <p className="body" style={{ color: "var(--ink-2)" }}>
                You'll work directly with the lead combat and narrative designers, ship balance patches every other Friday, and have a real seat at the strategy table.
              </p>
            </section>
            <section>
              <h2 className="h2" style={{ marginBottom: 12 }}>You'll do</h2>
              <ul className="body" style={{ paddingLeft: 20, color: "var(--ink-2)" }}>
                <li>Design and tune economy, progression, and faction systems for an open-world RPG</li>
                <li>Build playtest spreadsheets &amp; live dashboards in our tooling stack</li>
                <li>Pair with combat &amp; narrative leads on faction politics design</li>
                <li>Own balance patches every other Friday post-launch</li>
              </ul>
            </section>
            <section>
              <h2 className="h2" style={{ marginBottom: 12 }}>You bring</h2>
              <ul className="body" style={{ paddingLeft: 20, color: "var(--ink-2)" }}>
                <li>3+ years on a shipped game, ideally one with a live-ops layer</li>
                <li>Comfort with Unity, spreadsheets, and lightweight scripting</li>
                <li>Tabletop / board-game design experience is a bonus we love</li>
              </ul>
            </section>
            <section>
              <h2 className="h2" style={{ marginBottom: 12 }}>How we hire</h2>
              <Stepper current="Applied" />
              <p className="muted" style={{ fontSize: 13, marginTop: 14 }}>
                Take-home is paid (€400) and capped at 4 hours. We tell you within a week, every time.
              </p>
            </section>
          </div>

          <aside className="col" style={{ gap: 16 }}>
            <div className="card p-5">
              <div className="eyebrow" style={{ marginBottom: 8 }}>About Aurora</div>
              <p className="body" style={{ margin: 0, color: "var(--ink-2)", fontSize: 14 }}>
                A 48-person remote studio founded in 2014. Best known for <em>Hollow Ridge</em> and <em>Driftbound</em>.
              </p>
              <hr className="divider" style={{ margin: "14px 0" }} />
              <div className="eyebrow" style={{ marginBottom: 8 }}>Shipped</div>
              <div className="row wrap gap-2">
                <span className="chip">Hollow Ridge</span>
                <span className="chip">Driftbound</span>
                <span className="chip">Kelp &amp; Crown</span>
              </div>
              <hr className="divider" style={{ margin: "14px 0" }} />
              <div className="eyebrow" style={{ marginBottom: 8 }}>Tech</div>
              <div className="row wrap gap-2">
                <span className="chip">Unity 2023.3</span>
                <span className="chip">C#</span>
                <span className="chip">Perforce</span>
              </div>
            </div>

            <div className="card p-5" style={{ background: "var(--accent-soft)", borderColor: "var(--accent-2)" }}>
              <div className="row gap-2" style={{ marginBottom: 10 }}>
                <span className="dot dot-sage" /> <span className="mono" style={{ fontSize: 11, fontWeight: 600 }}>WORKING HERE</span>
              </div>
              <div className="col gap-2" style={{ fontSize: 14 }}>
                <div>🌴 32 days PTO</div>
                <div>🏠 Fully remote, EU hours</div>
                <div>🚫 No-crunch policy <span className="pill pill-sage" style={{ marginLeft: 4 }}>verified</span></div>
                <div>🛂 Visa &amp; relocation support</div>
                <div>💰 €400 paid take-home</div>
              </div>
            </div>

            <div className="card p-5">
              <div className="eyebrow" style={{ marginBottom: 8 }}>Glassdoor signal</div>
              <div className="row between">
                <div>
                  <div className="h2" style={{ fontSize: 32 }}>4.3<span className="mono dim" style={{ fontSize: 13 }}>/5</span></div>
                  <div className="mono dim" style={{ fontSize: 11 }}>184 reviews</div>
                </div>
                <div className="col" style={{ gap: 4, alignItems: "flex-end", fontSize: 12, color: "var(--ink-2)" }}>
                  <span>WLB &nbsp; <strong>4.5</strong></span>
                  <span>Mgmt &nbsp; <strong>4.1</strong></span>
                  <span>Comp &nbsp; <strong>4.0</strong></span>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { HiDetail });
