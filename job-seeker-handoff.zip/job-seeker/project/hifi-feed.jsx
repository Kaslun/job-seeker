// Feed screen — list with daily-5 + streak + swipe-out

const HiFeed = () => {
  const [jobs, setJobs] = React.useState(JOBS);
  const [exiting, setExiting] = React.useState({});
  const [done, setDone] = React.useState(2);
  const [hovered, setHovered] = React.useState(null); // {id, dir}

  const decide = (id, dir) => {
    if (exiting[id]) return;
    setExiting(e => ({ ...e, [id]: dir }));
    setTimeout(() => {
      setJobs(js => js.filter(j => j.id !== id));
      setDone(d => Math.min(5, d + 1));
    }, 450);
  };

  React.useEffect(() => {
    const onKey = (e) => {
      if (jobs.length === 0) return;
      const top = jobs[0];
      if (e.key === "ArrowRight" || e.key === "j") decide(top.id, "right");
      if (e.key === "ArrowLeft" || e.key === "k") decide(top.id, "left");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--paper)" }} className="no-scrollbar">
      <TopNav active="Feed" />
      <div style={{ padding: "32px 60px 60px", maxWidth: 920, margin: "0 auto" }}>
        <div className="row between" style={{ alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>Tuesday · Apr 7</div>
            <h1 className="h1">Today's <span className="draw-u">roles</span>.</h1>
          </div>
          <span className="kbd-hint"><kbd>←</kbd><kbd>→</kbd> to decide · <kbd>U</kbd> undo</span>
        </div>

        {/* Daily 5 progress card */}
        <div className="card p-5" style={{ marginBottom: 24 }}>
          <div className="row between" style={{ marginBottom: 14 }}>
            <div>
              <div className="h3">Daily 5</div>
              <div className="muted" style={{ fontSize: 13 }}>Decide on five and you're done for the day.</div>
            </div>
            <div className="row gap-4">
              <div className="row gap-2"><span className="mono dim">PROGRESS</span><span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>{done} / 5</span></div>
            </div>
          </div>
          <div className="daily-bars">
            {[0, 1, 2, 3, 4].map(i => (
              <div key={i} className={i < done ? "done" : i === done ? "now" : ""} />
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="row between" style={{ marginBottom: 16 }}>
          <div className="row gap-2 wrap">
            <span className="chip chip-accent">{ICONS.filter()} 32 matches</span>
            <span className="chip">Unity ✕</span>
            <span className="chip">Remote ✕</span>
            <span className="chip">Mid level ✕</span>
            <span className="chip chip-outline">+ filter</span>
          </div>
          <span className="mono dim">sorted: best match</span>
        </div>

        {/* Job cards */}
        <div className="col gap-3">
          {jobs.map((j, idx) => {
            const ex = exiting[j.id];
            const isTop = idx === 0;
            return (
              <div key={j.id} className={"card feed-card p-5" + (ex === "right" ? " exit-right" : ex === "left" ? " exit-left" : "")}
                style={{ position: "relative" }}
                onMouseLeave={() => setHovered(null)}>
                {hovered && hovered.id === j.id && (
                  <div className={"decision-stamp " + hovered.dir} style={{ opacity: 1 }}>
                    {hovered.dir === "right" ? "save" : "pass"}
                  </div>
                )}
                <div className="row gap-4 start">
                  <CoverArt studio={j.studio} title={j.game} style={{ width: 200, flex: "0 0 200px" }} />
                  <div className="grow">
                    <div className="row between start" style={{ marginBottom: 8 }}>
                      <div>
                        <div className="row gap-2" style={{ marginBottom: 4 }}>
                          <span className="eyebrow">{j.studioName}</span>
                          {isTop && <span className="mono" style={{ fontSize: 10, padding: "1px 6px", background: "var(--ink)", color: "var(--paper)", borderRadius: 999 }}>UP NEXT</span>}
                        </div>
                        <h2 className="h2" style={{ fontSize: 26 }}>{j.title}</h2>
                      </div>
                      <MatchRing pct={j.match} />
                    </div>
                    <div className="row wrap gap-3" style={{ fontSize: 13, color: "var(--ink-2)", marginBottom: 10 }}>
                      <span className="row gap-2">{ICONS.pin()} {j.loc}</span>
                      <span className="row gap-2">{ICONS.cash()} {j.pay}</span>
                      <span className="row gap-2">{ICONS.cal()} {j.posted}</span>
                    </div>
                    <p className="body" style={{ margin: "0 0 12px", color: "var(--ink-2)", fontSize: 14 }}>{j.pitch}</p>
                    <div className="row between">
                      <TagRow tags={j.tags} variant="accent-first" />
                      <div className="row gap-2">
                        <button className="btn btn-icon"
                          title="Pass · gone forever (←)"
                          onMouseEnter={() => setHovered({ id: j.id, dir: "left" })}
                          onMouseLeave={() => setHovered(null)}
                          onClick={() => decide(j.id, "left")}>
                          {ICONS.x()}
                        </button>
                        <button className="btn btn-icon"
                          title="Park · decide later"
                          onClick={() => decide(j.id, "right")}>
                          {ICONS.bookmark()}
                        </button>
                        <button className="btn btn-icon btn-primary"
                          title="Save · keep for later (→)"
                          onMouseEnter={() => setHovered({ id: j.id, dir: "right" })}
                          onMouseLeave={() => setHovered(null)}
                          onClick={() => decide(j.id, "right")}>
                          <span style={{ color: "var(--ink)" }}>{ICONS.heart(true)}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          {jobs.length === 0 && (
            <div className="card p-8 center" style={{ flexDirection: "column", textAlign: "center", background: "var(--accent-soft)", borderColor: "var(--accent-2)" }}>
              <div className="h1" style={{ fontSize: 48 }}>You're done.</div>
              <p className="muted" style={{ maxWidth: 400 }}>Five decisions today. That's enough — your streak is safe. Come back tomorrow for fresh roles.</p>
              <div className="row gap-3" style={{ marginTop: 12 }}>
                <button className="btn btn-lg">Review what you saved</button>
                <button className="btn btn-lg btn-primary">See you tomorrow {ICONS.arrow()}</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { HiFeed });
