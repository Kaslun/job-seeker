// Print-only app: each artboard becomes its own page

const PrintFrame = ({ label, w, h, children, scale = 1 }) => (
  <section className="print-page" style={{ "--w": w + "px", "--h": h + "px" }}>
    <div className="print-meta">
      <span className="print-label">{label}</span>
      <span className="print-dims">{w} × {h}</span>
    </div>
    <div className="print-board" style={{ width: w, height: h, transform: `scale(${scale})`, transformOrigin: "top left" }}>
      {children}
    </div>
  </section>
);

const PrintApp = () => {
  // Set tweaks (CSS variables) — same defaults as live
  React.useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent", "#ffd84d");
    r.style.setProperty("--paper", "#faf8f1");
    r.style.setProperty("--ink", "#15130f");
    r.style.setProperty("--f-display", "'Bricolage Grotesque', serif");
    r.style.setProperty("--f-body", "'Geist', system-ui, sans-serif");
    document.body.classList.add("no-anno");
  }, []);

  // Cover content extracted (render directly, no DesignCanvas)
  const Cover = () => (
    <div style={{ height: "100%", padding: "70px 70px 56px", display: "flex", flexDirection: "column", justifyContent: "space-between", gap: 40, background: "var(--paper)" }}>
      <div className="row between">
        <Logo size="lg" />
        <div className="row gap-3">
          <span className="chip">v3 · hi-fi</span>
          <span className="chip chip-accent">designed for ADHD</span>
        </div>
      </div>
      <div>
        <div className="eyebrow" style={{ marginBottom: 16 }}>A JOB BOARD FOR INTERNATIONAL GAME DESIGNERS</div>
        <h1 style={{ fontFamily: "var(--f-display)", fontSize: 88, lineHeight: 0.95, letterSpacing: "-0.03em", margin: "0 0 22px", maxWidth: 1100, fontWeight: 700 }}>
          Five jobs.<br />Five decisions.<br /><span className="draw-u">You're done</span><br />for the day.
        </h1>
        <p className="body muted" style={{ fontSize: 19, maxWidth: 720, margin: 0 }}>
          Most boards punish you for not scrolling forever. questboard makes job hunting <em>finishable</em> — five swipes, then it locks the feed and tells you to go live your life.
        </p>
      </div>
      <div className="row gap-4 wrap">
        {[
          ["⊙ One decision at a time", "Like or dismiss. No 'maybe' pile."],
          ["⌖ Same answers, every time", "Salary · location · stack · timeline · who you'd work with."],
          ["✓ Finishable, not infinite", "Daily 5, not endless feed."],
          ["⛬ Stage-aware tracker", "Always know what's next."],
        ].map((p, i) => (
          <div key={i} style={{ flex: "1 1 240px", padding: "16px 0", borderTop: "1.5px solid var(--ink)" }}>
            <div className="h3" style={{ fontSize: 16, marginBottom: 4 }}>{p[0]}</div>
            <div className="muted" style={{ fontSize: 13 }}>{p[1]}</div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <>
      <PrintFrame label="Cover" w={1280} h={780}><Cover /></PrintFrame>
      <PrintFrame label="01 · Feed · desktop" w={1280} h={900}><HiFeed /></PrintFrame>
      <PrintFrame label="01 · Feed · mobile" w={420} h={820}>
        <div style={{ width: 420, height: 820, display: "flex", alignItems: "center", justifyContent: "center" }}><HiMobile /></div>
      </PrintFrame>
      <PrintFrame label="02 · Job detail" w={1280} h={1280}><HiDetail /></PrintFrame>
      <PrintFrame label="03 · Onboarding · step 2/4" w={1280} h={760}><HiOnboard /></PrintFrame>
      <PrintFrame label="04 · Tracker overview" w={1280} h={900}><HiTracker /></PrintFrame>
      <PrintFrame label="04 · Single application" w={1280} h={1100}><HiApplication /></PrintFrame>
    </>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<PrintApp />);

// Auto-print after fonts + a safety delay
(async () => {
  try { if (document.fonts && document.fonts.ready) await document.fonts.ready; } catch (e) {}
  setTimeout(() => { window.print(); }, 700);
})();
