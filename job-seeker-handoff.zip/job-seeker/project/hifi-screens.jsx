// Onboarding wizard (hi-fi) + Tracker overview + Single application + Mobile feed

// ─── Onboarding · Step 2/4 (engines) ───
const HiOnboard = () => {
  const [picked, setPicked] = React.useState(["Unity", "Unreal"]);
  const toggle = (e) => setPicked(p => p.includes(e) ? p.filter(x => x !== e) : [...p, e]);
  const engines = ["Unity", "Unreal", "Godot", "Custom / proprietary", "GameMaker", "Roblox", "Web (PixiJS, Phaser)"];
  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--paper)", padding: "40px 60px" }} className="no-scrollbar">
      <div className="row between" style={{ marginBottom: 40 }}>
        <Logo />
        <span className="kbd-hint">save &amp; come back anytime</span>
      </div>
      <div style={{ maxWidth: 720, margin: "0 auto", textAlign: "center" }}>
        <div className="eyebrow" style={{ marginBottom: 14 }}>STEP 2 / 4 · ENGINES</div>
        <div className="daily-bars" style={{ maxWidth: 320, margin: "0 auto 32px" }}>
          {[0, 1, 2, 3].map(i => <div key={i} className={i < 2 ? "done" : i === 2 ? "now" : ""} />)}
        </div>
        <h1 className="h1" style={{ marginBottom: 12 }}>What engines feel like <span className="draw-u">home</span>?</h1>
        <p className="body muted" style={{ marginBottom: 32, fontSize: 17 }}>Pick all that apply. Skip anything that doesn't matter.</p>
        <div className="row wrap gap-3" style={{ justifyContent: "center", marginBottom: 40 }}>
          {engines.map(e => {
            const on = picked.includes(e);
            return (
              <button key={e} onClick={() => toggle(e)} className={"btn btn-lg" + (on ? " btn-primary" : "")}>
                {on && ICONS.check()} {e}
              </button>
            );
          })}
        </div>
        <div className="row gap-3" style={{ justifyContent: "center" }}>
          <button className="btn btn-lg btn-flat">← back</button>
          <button className="btn btn-xl btn-primary">Next: genres {ICONS.arrow()}</button>
          <button className="btn btn-lg btn-ghost">skip</button>
        </div>
        <p className="mono dim" style={{ marginTop: 24, fontSize: 11 }}>YOU CAN EDIT ANY OF THIS LATER FROM YOUR PROFILE</p>
      </div>
    </div>
  );
};

// ─── Tracker overview ───
const HiTracker = () => {
  const rows = [
    { studio: "AURORA", name: "Aurora Works", title: "Systems Designer", stage: "Interview", date: "Tue 14:00", note: "Panel · 90 min" },
    { studio: "MOSSGATE", name: "Mossgate Studio", title: "Level Designer", stage: "Take-home", date: "due Mar 28", note: "4h · paid €400" },
    { studio: "HALFLIGHT", name: "Halflight Games", title: "Narrative Designer", stage: "Screen", date: "yesterday", note: "Replied — booking" },
    { studio: "POLARFOX", name: "Polarfox", title: "UX Designer", stage: "Applied", date: "1 week ago", note: "" },
    { studio: "BRIGHT", name: "Bright Hollow", title: "UI Designer", stage: "Applied", date: "2 weeks ago", rejected: true, note: "" },
  ];
  return (
    <div style={{ height: "100%", overflow: "auto", background: "var(--paper)" }} className="no-scrollbar">
      <TopNav active="Applied" />
      <div style={{ padding: "32px 60px 60px", maxWidth: 1080, margin: "0 auto" }}>
        <div className="row between end" style={{ marginBottom: 24 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>14 active applications</div>
            <h1 className="h1">Where you <span className="draw-u">are</span>.</h1>
          </div>
          <div className="row gap-2">
            <span className="chip">{ICONS.filter()} All ▾</span>
            <span className="chip chip-accent">2 awaiting reply</span>
          </div>
        </div>

        {/* This-week summary */}
        <div className="card p-5" style={{ marginBottom: 24 }}>
          <div className="row between" style={{ marginBottom: 14 }}>
            <div>
              <div className="h3">This week</div>
              <div className="muted" style={{ fontSize: 13 }}>3 applied · 1 reply · 1 interview booked</div>
            </div>
            <div className="row gap-3">
              <div className="col" style={{ alignItems: "flex-end", gap: 0 }}>
                <span className="h2" style={{ fontSize: 22 }}>3<span className="mono dim" style={{ fontSize: 12 }}>/wk</span></span>
                <span className="mono dim" style={{ fontSize: 10 }}>GOAL · 3</span>
              </div>
              <span className="pill pill-sage">on pace</span>
            </div>
          </div>
          <div className="day-strip">
            {[
              { d: "M", v: 1 }, { d: "T", v: 1 }, { d: "W", v: 1, today: true },
              { d: "T", v: 0 }, { d: "F", v: 0 }, { d: "S", v: 0 }, { d: "S", v: 0 },
            ].map((d, i) => (
              <div key={i} className={"day" + (d.v ? " done" : "") + (d.today ? " today" : "")}>
                <div>{d.d}</div>
                {d.v ? <strong style={{ fontSize: 14, color: "var(--ink)" }}>✓</strong> : null}
              </div>
            ))}
          </div>
        </div>

        {/* Application rows */}
        <div className="col gap-2">
          {rows.map((r, i) => (
            <div key={i} className="card p-4" style={{ opacity: r.rejected ? 0.6 : 1, transition: "transform .15s, box-shadow .15s", cursor: "pointer" }}>
              <div className="row between gap-4">
                <div className="row gap-3 grow" style={{ minWidth: 0 }}>
                  <StudioMark studio={r.studio} size={48} />
                  <div style={{ minWidth: 0 }}>
                    <div className="eyebrow" style={{ fontSize: 10 }}>{r.name}</div>
                    <div className="h3" style={{ fontSize: 18, marginBottom: 2 }}>{r.title}</div>
                    {r.note && <div className="mono dim" style={{ fontSize: 11 }}>{r.note}</div>}
                  </div>
                </div>
                <div className="col" style={{ alignItems: "flex-end", gap: 8, flex: "0 0 auto" }}>
                  <MiniStepper current={r.stage} rejected={r.rejected} />
                  <div className="row gap-3">
                    <span className="mono dim" style={{ fontSize: 11 }}>{r.date}</span>
                    <StagePill stage={r.stage} rejected={r.rejected} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Single application detail ───
const HiApplication = () => (
  <div style={{ height: "100%", overflow: "auto", background: "var(--paper)" }} className="no-scrollbar">
    <TopNav active="Applied" />
    <div style={{ padding: "24px 60px 60px", maxWidth: 1080, margin: "0 auto" }}>
      <span className="row gap-2 mono dim" style={{ fontSize: 12, marginBottom: 18, cursor: "pointer" }}>← all applications</span>

      <div className="row between start" style={{ marginBottom: 28 }}>
        <div className="row gap-4">
          <StudioMark studio="AURORA" size={72} />
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>AURORA WORKS</div>
            <h1 className="h1" style={{ fontSize: 40 }}>Systems Designer</h1>
            <div className="row wrap gap-3" style={{ marginTop: 10, fontSize: 13, color: "var(--ink-2)" }}>
              <span className="row gap-2">{ICONS.pin()} Remote · EU</span>
              <span className="row gap-2">{ICONS.cash()} €55–70k</span>
              <span className="row gap-2">{ICONS.cal()} Applied Mar 12</span>
            </div>
          </div>
        </div>
        <span className="pill pill-sage" style={{ fontSize: 12, padding: "6px 14px" }}>● Interview booked</span>
      </div>

      {/* Big stepper */}
      <div className="card p-5" style={{ marginBottom: 28 }}>
        <div className="row between" style={{ marginBottom: 18 }}>
          <div className="h3">Where you are <span className="muted" style={{ fontWeight: 400, fontSize: 14 }}>· stage 4 of 5</span></div>
          <span className="mono dim">est. 2 weeks left</span>
        </div>
        <Stepper current="Interview" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 28 }}>
        {/* Timeline */}
        <div>
          <div className="h3" style={{ marginBottom: 16 }}>Timeline</div>
          <div className="col gap-4" style={{ position: "relative", paddingLeft: 32, borderLeft: "2px dashed var(--paper-3)", marginLeft: 8 }}>
            {[
              { d: "Mar 12", t: "Applied", n: "Cover letter v3 + portfolio link", done: true },
              { d: "Mar 14", t: "Auto-reply received", done: true },
              { d: "Mar 16", t: "Recruiter screen ✓", n: "30 min · with Mara H.", done: true },
              { d: "Mar 21", t: "Take-home submitted ✓", n: "4h · economy tuning brief", done: true },
              { d: "Apr 02", t: "Panel interview booked", n: "Tue 14:00 · 90 min · with Mara, Liam, Priya", up: true },
            ].map((s, i) => (
              <div key={i} className="row gap-3 start" style={{ position: "relative" }}>
                <div style={{
                  position: "absolute", left: -42,
                  width: 16, height: 16, borderRadius: "50%",
                  background: s.up ? "var(--accent)" : s.done ? "var(--ink)" : "var(--card)",
                  border: "2px solid " + (s.up || s.done ? "var(--ink)" : "var(--paper-3)"),
                  marginTop: 4,
                  boxShadow: s.up ? "0 0 0 4px var(--accent-soft)" : "none",
                }} />
                <div>
                  <div className="mono dim" style={{ fontSize: 11 }}>{s.d}</div>
                  <div className="h3" style={{ fontSize: 17 }}>{s.t}</div>
                  {s.n && <div className="muted" style={{ fontSize: 13 }}>{s.n}</div>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <aside className="col gap-4">
          <div className="card p-5" style={{ background: "var(--accent-soft)", borderColor: "var(--accent-2)" }}>
            <div className="eyebrow" style={{ marginBottom: 8 }}>↗ NEXT STEP</div>
            <div className="h3" style={{ marginBottom: 4 }}>Panel interview</div>
            <p className="body" style={{ margin: "0 0 14px", color: "var(--ink-2)", fontSize: 14 }}>Tue 14:00 CET · 90 min · with Mara, Liam, and Priya.</p>
            <div className="col gap-2">
              <button className="btn" style={{ width: "100%", justifyContent: "center" }}>{ICONS.cal()} Add to calendar</button>
              <button className="btn btn-flat" style={{ width: "100%", justifyContent: "center" }}>Open prep checklist</button>
              <button className="btn btn-flat" style={{ width: "100%", justifyContent: "center", fontSize: 13 }}>Break this into 30-min chunks</button>
            </div>
          </div>
          <div className="card p-5">
            <div className="eyebrow" style={{ marginBottom: 8 }}>YOUR NOTES</div>
            <div className="body" style={{ color: "var(--ink-2)", fontSize: 14 }}>
              Mara's into systemic narrative. Bring the faction-rep curve from <em>Driftbound</em> playthrough — she'll like that.
            </div>
          </div>
          <div className="card p-5">
            <div className="eyebrow" style={{ marginBottom: 8 }}>FILES</div>
            <div className="col gap-2">
              <div className="row between"><span className="mono" style={{ fontSize: 12 }}>cover_v3.pdf</span><span className="mono dim" style={{ fontSize: 11 }}>180 kb</span></div>
              <div className="row between"><span className="mono" style={{ fontSize: 12 }}>takehome.zip</span><span className="mono dim" style={{ fontSize: 11 }}>2.4 mb</span></div>
              <div className="row between"><span className="mono" style={{ fontSize: 12 }}>portfolio_2026.pdf</span><span className="mono dim" style={{ fontSize: 11 }}>4.1 mb</span></div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
);

// ─── Mobile feed (swipe) ───
const HiMobile = () => {
  const [jobs, setJobs] = React.useState(JOBS);
  const [exiting, setExiting] = React.useState({});
  const [done, setDone] = React.useState(2);
  const decide = (id, dir) => {
    if (exiting[id]) return;
    setExiting(e => ({ ...e, [id]: dir }));
    setTimeout(() => {
      setJobs(js => js.filter(j => j.id !== id));
      setDone(d => Math.min(5, d + 1));
    }, 450);
  };
  const top = jobs[0];
  return (
    <div className="phone">
      <div className="notch" />
      <div className="screen">
        <div className="row between" style={{ padding: "8px 18px 12px" }}>
          <Logo />
          <span className="streak" style={{ fontSize: 11, padding: "4px 10px" }}><span>🔥</span> 7</span>
        </div>
        <div style={{ padding: "0 18px 8px" }}>
          <div className="row between" style={{ marginBottom: 6, alignItems: "flex-end" }}>
            <span className="mono dim" style={{ fontSize: 11 }}>DAILY 5</span>
            <span className="mono" style={{ fontSize: 12, fontWeight: 600 }}>{done}/5</span>
          </div>
          <div className="daily-bars" style={{ gap: 4 }}>
            {[0, 1, 2, 3, 4].map(i => <div key={i} className={i < done ? "done" : i === done ? "now" : ""} style={{ height: 6 }} />)}
          </div>
        </div>

        <div style={{ position: "relative", height: 460, margin: "16px 18px 0" }}>
          {jobs.length === 0 ? (
            <div className="card p-5 center" style={{ flexDirection: "column", height: "100%", textAlign: "center", background: "var(--accent-soft)", borderColor: "var(--accent-2)" }}>
              <div className="h2" style={{ fontSize: 28 }}>You're done.</div>
              <p className="muted" style={{ fontSize: 13 }}>Streak safe — see you tomorrow.</p>
            </div>
          ) : jobs.slice(0, 3).reverse().map((j, ridx) => {
            const idx = jobs.slice(0, 3).length - 1 - ridx;
            const isTop = idx === 0;
            const ex = exiting[j.id];
            const stack = idx === 1 ? { transform: "translate(0, 8px) scale(0.96)", opacity: 0.85 } :
                          idx === 2 ? { transform: "translate(0, 16px) scale(0.92)", opacity: 0.7 } : {};
            const exit = ex === "right" ? { transform: "translateX(400px) rotate(15deg)", opacity: 0, transition: "transform .45s, opacity .45s" } :
                         ex === "left" ? { transform: "translateX(-400px) rotate(-15deg)", opacity: 0, transition: "transform .45s, opacity .45s" } : {};
            return (
              <div key={j.id} className="card" style={{
                position: "absolute", inset: 0,
                transition: "transform .25s, opacity .25s",
                ...stack, ...exit,
                zIndex: 10 - idx,
                overflow: "hidden",
              }}>
                <CoverArt studio={j.studio} title={j.game} style={{ aspectRatio: "auto", height: 160 }} />
                <div className="p-4">
                  <div className="row between start" style={{ marginBottom: 6 }}>
                    <div className="eyebrow" style={{ fontSize: 10 }}>{j.studioName}</div>
                    <MatchRing pct={j.match} size={36} />
                  </div>
                  <div className="h2" style={{ fontSize: 22, marginBottom: 8 }}>{j.title}</div>
                  <div className="row wrap gap-2" style={{ fontSize: 12, color: "var(--ink-2)", marginBottom: 8 }}>
                    <span>{ICONS.pin()} {j.loc}</span>
                    <span>{ICONS.cash()} {j.pay}</span>
                  </div>
                  <p className="body" style={{ fontSize: 13, color: "var(--ink-2)", margin: 0 }}>{j.pitch}</p>
                  <div className="row wrap gap-2" style={{ marginTop: 10 }}>
                    {j.tags.slice(0, 3).map((t, i) => <span key={i} className={"chip" + (i === 0 ? " chip-accent" : "")} style={{ fontSize: 11 }}>{t}</span>)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {jobs.length > 0 && (
          <div className="row" style={{ justifyContent: "space-around", padding: "20px 18px", position: "absolute", bottom: 24, left: 0, right: 0 }}>
            <button className="btn btn-icon-lg" onClick={() => decide(top.id, "left")}>{ICONS.x()}</button>
            <button className="btn btn-icon" onClick={() => decide(top.id, "right")}>{ICONS.bookmark()}</button>
            <button className="btn btn-icon-lg btn-primary" onClick={() => decide(top.id, "right")}>{ICONS.heart(true)}</button>
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { HiOnboard, HiTracker, HiApplication, HiMobile });
