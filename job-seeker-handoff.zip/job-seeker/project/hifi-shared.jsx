// Shared hi-fi components

const ICONS = {
  heart: (filled = false) => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round">
      <path d="M12 21s-7-4.5-7-10.5A4.5 4.5 0 0 1 12 6a4.5 4.5 0 0 1 7 4.5C19 16.5 12 21 12 21z" />
    </svg>
  ),
  x: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l14 14M19 5L5 19" /></svg>,
  check: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12l5 5L20 6" /></svg>,
  bookmark: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><path d="M6 4h12v17l-6-4-6 4z" /></svg>,
  arrow: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>,
  search: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>,
  bell: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M6 8a6 6 0 0 1 12 0v5l2 3H4l2-3z M10 19a2 2 0 0 0 4 0" /></svg>,
  flame: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c.4 4.5 3.5 5.7 4.5 9 .9 3.1-.7 7.5-4.5 8.5-3.8 1-7-2-7-5.5 0-2 1.5-3 2.5-2.5C7 11 6 9 8 6.5 9.5 4.7 12 4 12 2z"/></svg>,
  pin: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M12 22s7-7 7-12a7 7 0 0 0-14 0c0 5 7 12 7 12z" /><circle cx="12" cy="10" r="2.5" /></svg>,
  cash: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/></svg>,
  globe: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></svg>,
  cal: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>,
  filter: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 5h18l-7 9v6l-4-2v-4z"/></svg>,
};

const Logo = ({ size = "md" }) => (
  <div className="logo" style={{ fontSize: size === "lg" ? 24 : 18 }}>
    <span className="logo-mark" style={{ width: size === "lg" ? 36 : 28, height: size === "lg" ? 36 : 28 }}></span>
    <span>questboard</span>
  </div>
);

const TopNav = ({ active = "Feed", showStreak = true }) => (
  <div className="topnav">
    <Logo />
    <div className="nav-links">
      {["Feed", "Saved", "Applied", "Profile"].map(n => (
        <span key={n} className={"nav-link" + (n === active ? " active" : "")}>{n}</span>
      ))}
    </div>
    <div className="row gap-3">
      <button className="btn btn-flat" style={{ padding: "8px 12px", fontSize: 13 }}>{ICONS.search()} Search</button>
      {showStreak && (
        <span className="streak"><span className="flame">🔥</span> 7-day streak</span>
      )}
    </div>
  </div>
);

// Studio palettes — generated cover art uses these
const STUDIO_PALETTES = {
  AURORA:    { ca1: "#1a3a5e", ca2: "#ff8c42", ca3: "#3a6b8c", ca4: "#0c1d33" },
  MOSSGATE:  { ca1: "#2a4a3a", ca2: "#a8c66c", ca3: "#1c3527", ca4: "#0e1a14" },
  HALFLIGHT: { ca1: "#3d2a55", ca2: "#e8a3c2", ca3: "#5a3a7a", ca4: "#1f1530" },
  POLARFOX:  { ca1: "#1c4a5a", ca2: "#7adfdf", ca3: "#0e2a36", ca4: "#091820" },
  TIDEWAVE:  { ca1: "#1a2a4a", ca2: "#5a7adf", ca3: "#0d1a30", ca4: "#06101e" },
  EMBER:     { ca1: "#5a1a14", ca2: "#ff8a3c", ca3: "#3a0e0a", ca4: "#1f0805" },
  BRIGHT:    { ca1: "#5a4a1a", ca2: "#ffd84d", ca3: "#3a2f10", ca4: "#1a1408" },
};

const CoverArt = ({ studio = "AURORA", title = "Hollow Ridge", style = {} }) => {
  const p = STUDIO_PALETTES[studio] || STUDIO_PALETTES.AURORA;
  return (
    <div className="cover-art" style={{ "--ca-1": p.ca1, "--ca-2": p.ca2, "--ca-3": p.ca3, "--ca-4": p.ca4, ...style }}>
      <span className="ca-studio">{studio}</span>
      <div className="ca-title" style={{ fontSize: style.fontSize || 28 }}>{title}</div>
    </div>
  );
};

const StudioMark = ({ studio = "AURORA", size = 56 }) => {
  const p = STUDIO_PALETTES[studio] || STUDIO_PALETTES.AURORA;
  const initials = studio.slice(0, 2);
  return (
    <div className="studio-mark" style={{
      width: size, height: size, fontSize: size * 0.42,
      background: `linear-gradient(135deg, ${p.ca1}, ${p.ca4})`,
      color: "#fff",
      borderColor: p.ca4,
    }}>
      {initials}
    </div>
  );
};

const MatchRing = ({ pct = 92, size = 44 }) => (
  <div className="match-ring" style={{ "--p": pct, width: size, height: size }}>
    <span style={{ fontSize: size * 0.26 }}>{pct}</span>
  </div>
);

const StagePill = ({ stage, rejected = false }) => {
  if (rejected) return <span className="pill pill-rose">closed</span>;
  const map = {
    "Applied": "pill-ghost",
    "Screen": "pill-amber",
    "Take-home": "pill-amber",
    "Interview": "pill-sage",
    "Offer": "pill-sage",
  };
  return <span className={"pill " + (map[stage] || "pill-ghost")}>{stage}</span>;
};

const STAGES = ["Applied", "Screen", "Take-home", "Interview", "Offer"];

const Stepper = ({ current = "Interview", rejected = false }) => {
  const idx = STAGES.indexOf(current);
  return (
    <div className="row gap-3" style={{ alignItems: "stretch" }}>
      {STAGES.map((s, i) => (
        <React.Fragment key={s}>
          <div className="col" style={{ alignItems: "center", gap: 8, flex: "0 0 auto" }}>
            <div className={"node" + (i < idx && !rejected ? " done" : "") + (i === idx && !rejected ? " active" : "")}>
              {i < idx && !rejected ? "✓" : i + 1}
            </div>
            <div className={"label" + (i === idx && !rejected ? " active" : "")}>{s}</div>
          </div>
          {i < STAGES.length - 1 && (
            <div className="grow" style={{ display: "flex", alignItems: "center", paddingBottom: 18 }}>
              <div className={"conn" + (i < idx && !rejected ? " done" : "")} style={{ width: "100%" }}></div>
            </div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

const MiniStepper = ({ current, rejected = false }) => {
  const idx = STAGES.indexOf(current);
  return (
    <div className="mini-stepper">
      {STAGES.map((s, i) => (
        <React.Fragment key={s}>
          <div className={"dot" + (i < idx && !rejected ? " done" : "") + (i === idx && !rejected ? " active" : "")} title={s} />
          {i < STAGES.length - 1 && <div className={"bar" + (i < idx && !rejected ? " done" : "")} />}
        </React.Fragment>
      ))}
    </div>
  );
};

// Job data shared across screens
const JOBS = [
  {
    id: "j1", studio: "AURORA", studioName: "Aurora Works", title: "Systems Designer", game: "Hollow Ridge II",
    loc: "Remote · EU", pay: "€55–70k", level: "Mid", posted: "2d ago",
    tags: ["Unity", "RPG", "Live ops", "Visa-friendly"],
    pitch: "Tune systems & economy on an open-world RPG. Pair with combat + narrative leads.",
    match: 95, accent: true,
  },
  {
    id: "j2", studio: "MOSSGATE", studioName: "Mossgate Studio", title: "Level Designer", game: "Driftbound",
    loc: "Hybrid · Berlin", pay: "€48–60k", level: "Mid", posted: "3d ago",
    tags: ["Unreal", "FPS", "Multiplayer"],
    pitch: "Block out and ship sandbox arenas for a co-op shooter.",
    match: 81,
  },
  {
    id: "j3", studio: "HALFLIGHT", studioName: "Halflight Games", title: "Narrative Designer", game: "Kelp & Crown",
    loc: "Remote · World", pay: "$70–90k", level: "Senior", posted: "5d ago",
    tags: ["Twine", "Branching", "Adventure"],
    pitch: "Write and structure branching dialogue for a small-team adventure.",
    match: 78,
  },
  {
    id: "j4", studio: "POLARFOX", studioName: "Polarfox", title: "UX Designer", game: "Tides of Aether",
    loc: "Remote · EU", pay: "€50–62k", level: "Mid", posted: "1w ago",
    tags: ["Mobile", "F2P", "Figma"],
    pitch: "Onboarding + core loop UX for a mobile gacha.",
    match: 72,
  },
];

const TagRow = ({ tags = [], variant = "default" }) => (
  <div className="row wrap gap-2">
    {tags.map((t, i) => (
      <span key={i} className={"chip" + (i === 0 && variant === "accent-first" ? " chip-accent" : "")}>{t}</span>
    ))}
  </div>
);

const Anno = ({ children, top, left, right, bottom, dotPos }) => (
  <div className="anno" style={{ top, left, right, bottom }}>
    <span className="dot dot-accent" /> {children}
  </div>
);

Object.assign(window, { ICONS, Logo, TopNav, CoverArt, StudioMark, MatchRing, StagePill, Stepper, MiniStepper, STAGES, JOBS, TagRow, Anno, STUDIO_PALETTES });
