// Job detail page variants

// ─── A · Two-column classic ────────────────────────────────────────
const DetailClassic = () => (
  <div className="wf">
    <Chrome active="Feed" />
    <div className="row" style={{ gap: 10, marginBottom: 10 }}>
      <span className="wf-mono muted">← back to feed</span>
    </div>
    <div className="row between" style={{ alignItems: "flex-start", marginBottom: 12 }}>
      <div className="row" style={{ gap: 14 }}>
        <StudioMark size={72} name="AURORA" />
        <div>
          <div className="wf-mono muted" style={{ letterSpacing: 1 }}>AURORA WORKS</div>
          <h1 style={{ fontSize: 38 }}>Systems Designer</h1>
          <div className="row wrap muted" style={{ gap: 10, fontSize: 15 }}>
            <span>📍 Remote · EU</span><span>💰 €55–70k</span><span>🕒 Full-time</span><span>📅 2d ago</span>
          </div>
        </div>
      </div>
      <div className="col" style={{ alignItems: "flex-end", gap: 8 }}>
        <button className="wf-btn xl primary">Apply →</button>
        <div className="row" style={{ gap: 6 }}>
          <button className="wf-btn"><Heart /> Save</button>
          <button className="wf-btn ghost"><X /> Dismiss</button>
        </div>
      </div>
    </div>
    <TagRow tags={[{ label: "Unity", acc: true }, { label: "RPG" }, { label: "Mid level" }, { label: "Live ops" }, { label: "🌍 Visa-friendly", acc: true }]} />
    <div className="wf-divider" style={{ margin: "14px 0" }} />

    <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 18 }}>
      <div className="col" style={{ gap: 14 }}>
        <div>
          <h2>The role</h2>
          <Lines count={4} widths={["96%", "92%", "98%", "70%"]} />
        </div>
        <div>
          <h2>You'll do</h2>
          <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.6 }}>
            <li>Design systems for an open-world RPG</li>
            <li>Tune economy + progression curves</li>
            <li>Pair with combat &amp; narrative leads</li>
          </ul>
        </div>
        <div>
          <h2>You bring</h2>
          <Lines count={3} widths={["88%", "75%", "60%"]} />
        </div>
      </div>
      <div className="col" style={{ gap: 12 }}>
        <div className="wf-box fill-paper2">
          <div className="wf-hand" style={{ fontSize: 20, fontWeight: 700 }}>About Aurora</div>
          <div className="wf-mono muted" style={{ fontSize: 11 }}>FOUNDED 2014 · 48 PEOPLE</div>
          <Lines count={2} widths={["95%", "60%"]} />
          <div className="wf-mono muted" style={{ marginTop: 8 }}>SHIPPED</div>
          <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
            <span className="wf-chip">Hollow Ridge</span>
            <span className="wf-chip">Driftbound</span>
            <span className="wf-chip">Kelp &amp; Crown</span>
          </div>
        </div>
        <div className="wf-box">
          <div className="wf-hand" style={{ fontSize: 20, fontWeight: 700 }}>Working here</div>
          <div className="col" style={{ gap: 4, fontSize: 14, marginTop: 4 }}>
            <div>🌴 32 days PTO</div>
            <div>🏠 Fully remote, EU hours</div>
            <div>🚫 No-crunch policy <span className="wf-chip accent" style={{ fontSize: 11 }}>verified</span></div>
            <div>🛂 Visa &amp; relocation support</div>
          </div>
        </div>
      </div>
    </div>
    <Note top={60} right={24} rotate={-2} arrow="down" accent>
      apply button always<br />top-right. always.
    </Note>
    <Note bottom={60} left={6} rotate={-3} arrow="down-right">
      "verified" badges fight<br />job-listing FOMO
    </Note>
  </div>
);

// ─── B · TL;DR scannable ──────────────────────────────────────────
const DetailTLDR = () => (
  <div className="wf">
    <Chrome active="Feed" />
    <div className="row between" style={{ marginBottom: 8 }}>
      <span className="wf-mono muted">← back</span>
      <div className="wf-tabs"><button className="active">TL;DR</button><button>Full</button><button>Studio</button></div>
    </div>
    <div className="wf-box thick" style={{ background: "var(--accent)", padding: 16, marginBottom: 12 }}>
      <div className="wf-mono">AURORA WORKS · 2 DAYS AGO</div>
      <div className="wf-hand" style={{ fontSize: 36, fontWeight: 700, lineHeight: 1 }}>Systems Designer</div>
      <div className="row wrap" style={{ gap: 10, marginTop: 4, fontSize: 16 }}>
        <span>Remote EU</span>·<span>€55–70k</span>·<span>Mid</span>·<span>Unity</span>·<span>RPG</span>
      </div>
    </div>
    <div className="col" style={{ gap: 10 }}>
      {[
        { k: "What", v: "Tune systems & economy on an open-world RPG." },
        { k: "Why you", v: "3+ yrs Unity, shipped at least one live game." },
        { k: "Why them", v: "No-crunch verified · 32 PTO · visa-friendly." },
        { k: "Bonus", v: "Tabletop/board-game design experience." },
        { k: "Red flag?", v: "Crunch reviews from 2022 — fixed since." },
      ].map((row, i) => (
        <div key={i} className="row" style={{ gap: 12, alignItems: "flex-start" }}>
          <div className="wf-box tight" style={{ minWidth: 110, textAlign: "right", padding: "4px 10px", background: "var(--paper-2)" }}>
            <span className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>{row.k}</span>
          </div>
          <div className="grow" style={{ paddingTop: 4, fontSize: 16 }}>{row.v}</div>
        </div>
      ))}
    </div>
    <div className="wf-divider" style={{ margin: "14px 0" }} />
    <div className="row between">
      <div className="row" style={{ gap: 8 }}>
        <button className="wf-btn"><X /> not for me</button>
        <button className="wf-btn"><Bookmark /> park</button>
      </div>
      <button className="wf-btn xl primary">Apply now →</button>
    </div>
    <Note top={150} right={16} rotate={-3} arrow="down-left" accent>
      every job = the same<br />5 questions answered.<br />no scrolling-to-find.
    </Note>
    <Note bottom={20} left={20} rotate={2} arrow="up-right">
      decisions live next to facts
    </Note>
  </div>
);

// ─── C · Long-form / story ─────────────────────────────────────────
const DetailStory = () => (
  <div className="wf">
    <Chrome active="Feed" />
    <div className="row between" style={{ alignItems: "flex-start", marginBottom: 14 }}>
      <div>
        <span className="wf-mono muted">← back</span>
        <h1 style={{ fontSize: 44, marginTop: 6 }}>Help us tune a kingdom.</h1>
        <div className="muted" style={{ fontSize: 15, marginTop: 4 }}>Aurora Works · Systems Designer · Remote (EU)</div>
      </div>
      <div className="col" style={{ alignItems: "flex-end", gap: 6 }}>
        <button className="wf-btn xl primary">Apply →</button>
        <span className="wf-mono dim">⌘↵ to apply</span>
      </div>
    </div>
    <div className="wf-img" style={{ height: 180, marginBottom: 14 }}>cover image · gameplay GIF</div>
    <div style={{ columns: 2, columnGap: 24, fontSize: 15, lineHeight: 1.5 }}>
      <p style={{ margin: 0 }}>
        <span className="wf-hand" style={{ fontSize: 28, fontWeight: 700, float: "left", lineHeight: .8, marginRight: 6 }}>W</span>
        e're a 48-person remote studio. Last year we shipped <i>Hollow Ridge</i> — and now we're building something twice as ambitious.
      </p>
      <Lines count={6} widths={["98%", "94%", "100%", "88%", "92%", "70%"]} />
      <div style={{ marginTop: 8 }}><Lines count={4} widths={["96%", "100%", "84%", "60%"]} /></div>
    </div>
    <div className="row between" style={{ marginTop: 14 }}>
      <TagRow tags={[{ label: "Unity", acc: true }, { label: "RPG" }, { label: "No crunch ✓", acc: true }, { label: "Visa-friendly" }]} />
      <div className="row" style={{ gap: 6 }}>
        <button className="wf-btn"><X /></button>
        <button className="wf-btn primary"><Heart filled /> Save</button>
      </div>
    </div>
    <Note top={210} right={26} rotate={-2} arrow="down" accent>
      ⌘↵ shortcut → less<br />friction = more applies
    </Note>
  </div>
);

Object.assign(window, { DetailClassic, DetailTLDR, DetailStory });
