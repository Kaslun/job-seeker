// Feed variants — the core "browse jobs" experience.

// ─── A · Classic list ──────────────────────────────────────────────
const FeedList = () => (
  <div className="wf">
    <Chrome active="Feed" />
    <div className="row between" style={{ marginBottom: 12 }}>
      <h1>Today's roles</h1>
      <div className="row" style={{ gap: 8 }}>
        <span className="wf-chip">Engine: Unity ✕</span>
        <span className="wf-chip">Remote ✕</span>
        <span className="wf-chip dim">+ filter</span>
      </div>
    </div>
    <div className="wf-mono muted" style={{ marginBottom: 8 }}>32 matches · sorted by Newest</div>
    <div className="col" style={{ gap: 10 }}>
      <JobCard studio="AURORA WORKS" title="Systems Designer" loc="Remote · EU" pay="€55–70k"
        tags={[{ label: "Unity", acc: true }, { label: "RPG" }, { label: "Mid level" }]} />
      <JobCard studio="MOSSGATE STUDIO" title="Level Designer" loc="Hybrid · Berlin" pay="€48–60k"
        tags={[{ label: "Unreal" }, { label: "FPS" }, { label: "2 yrs+" }]} />
      <JobCard studio="HALFLIGHT GAMES" title="Narrative Designer" loc="Remote · Worldwide" pay="$70–90k"
        tags={[{ label: "Twine" }, { label: "Adventure", acc: true }, { label: "Senior" }]} />
    </div>
    <Note top={62} right={26} rotate={-3} arrow="down-right">
      ← like = save<br />✕ = gone forever<br />no maybe pile = no overwhelm
    </Note>
    <Note bottom={18} left={26} rotate={1} arrow="up" accent>
      one decision per card. that's it.
    </Note>
  </div>
);

// ─── B · Swipe / single-card focus ─────────────────────────────────
const FeedSwipe = () => (
  <div className="wf" style={{ background: "var(--paper)" }}>
    <Chrome active="Feed" />
    <div className="row between" style={{ marginBottom: 8 }}>
      <h1>One at a time.</h1>
      <div className="wf-chip">12 left in queue</div>
    </div>
    <div style={{ position: "relative", height: 360, margin: "12px auto 14px", maxWidth: 480 }}>
      <div className="stack-card behind-2" />
      <div className="stack-card behind-1" />
      <div className="stack-card" style={{ padding: 18, display: "flex", flexDirection: "column", gap: 10 }}>
        <div className="row between" style={{ alignItems: "flex-start" }}>
          <StudioMark size={56} name="AURORA" />
          <span className="wf-chip accent">95% match</span>
        </div>
        <div>
          <div className="wf-mono muted" style={{ letterSpacing: 1 }}>AURORA WORKS</div>
          <div className="wf-hand" style={{ fontSize: 36, fontWeight: 700, lineHeight: 1 }}>Systems Designer</div>
        </div>
        <div className="row wrap" style={{ gap: 6, fontSize: 14 }}>
          <span className="muted">📍 Remote · EU</span>
          <span className="muted">💰 €55–70k</span>
          <span className="muted">📅 posted 2d ago</span>
        </div>
        <TagRow tags={[{ label: "Unity", acc: true }, { label: "RPG" }, { label: "Mid" }, { label: "Live ops" }]} />
        <div style={{ flex: 1, minHeight: 0 }}>
          <Lines count={3} widths={["96%", "88%", "60%"]} />
        </div>
        <div className="row between">
          <span className="wf-mono dim">tap card → details</span>
          <span className="wf-mono dim">↶ undo</span>
        </div>
      </div>
    </div>
    <div className="row" style={{ justifyContent: "center", gap: 22 }}>
      <button className="wf-btn lg" style={{ width: 64, height: 64, borderRadius: "50%", padding: 0, justifyContent: "center" }}><X size={26} /></button>
      <button className="wf-btn lg" style={{ background: "var(--paper-2)" }}><Bookmark /> park for later</button>
      <button className="wf-btn lg primary" style={{ width: 64, height: 64, borderRadius: "50%", padding: 0, justifyContent: "center" }}><Heart filled size={26} /></button>
    </div>
    <Note top={120} left={6} rotate={-4} arrow="down-right">
      stack hints there's<br />more — but only 1<br />demands attention
    </Note>
    <Note top={400} right={8} rotate={3} arrow="left" accent>
      "park" = the maybe pile<br />w/o the regret
    </Note>
  </div>
);

// ─── C · Grid / visual browse ──────────────────────────────────────
const FeedGrid = () => (
  <div className="wf">
    <Chrome active="Feed" />
    <div className="row between" style={{ marginBottom: 10 }}>
      <h1>Browse</h1>
      <div className="row" style={{ gap: 6 }}>
        <span className="wf-chip">All roles ▾</span>
        <span className="wf-chip">Engine ▾</span>
        <span className="wf-chip">Genre ▾</span>
        <span className="wf-chip accent">Remote only ✓</span>
      </div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
      {[
        { s: "AURORA", t: "Systems Designer", g: "RPG" },
        { s: "MOSSGATE", t: "Level Designer", g: "FPS" },
        { s: "HALFLIGHT", t: "Narrative Designer", g: "Adventure" },
        { s: "POLARFOX", t: "UX Designer", g: "Mobile" },
        { s: "TIDEWAVE", t: "Combat Designer", g: "Action" },
        { s: "EMBER CO", t: "Economy Designer", g: "Sim" },
      ].map((j, i) => (
        <div key={i} className="wf-box" style={{ padding: 10 }}>
          <div className="wf-img" style={{ height: 70, marginBottom: 8 }}>cover art</div>
          <div className="wf-mono muted" style={{ fontSize: 10 }}>{j.s}</div>
          <div className="wf-hand" style={{ fontSize: 19, fontWeight: 700, lineHeight: 1.1 }}>{j.t}</div>
          <div className="row wrap" style={{ gap: 4, marginTop: 4 }}>
            <span className="wf-chip" style={{ fontSize: 11, padding: "0 6px" }}>{j.g}</span>
            <span className="wf-chip dim" style={{ fontSize: 11, padding: "0 6px" }}>Remote</span>
          </div>
          <div className="row between" style={{ marginTop: 8 }}>
            <span className="wf-mono dim">€50–70k</span>
            <LikeDislike />
          </div>
        </div>
      ))}
    </div>
    <Note top={48} left={300} rotate={-3} arrow="down">
      visual scan = good for hyperfocus days
    </Note>
    <Note bottom={16} right={20} rotate={2} accent>
      risk: too many = paralysis.<br />switch to <i>Focus</i> if stuck.
    </Note>
  </div>
);

// ─── D · Daily Focus mode ──────────────────────────────────────────
const FeedFocus = () => (
  <div className="wf" style={{ background: "var(--paper)" }}>
    <Chrome active="Feed" />
    <div className="row between" style={{ marginBottom: 6 }}>
      <h1>Today's 5.</h1>
      <div className="wf-chip accent">⏱ 8 min session</div>
    </div>
    <div className="muted" style={{ marginBottom: 10, fontSize: 15 }}>
      Hand-picked from your filters. Decide on these and you're done for today.
    </div>
    <div className="wf-box fill-paper2" style={{ padding: 12, marginBottom: 12 }}>
      <div className="row between" style={{ marginBottom: 6 }}>
        <span className="wf-hand" style={{ fontSize: 20, fontWeight: 700 }}>progress</span>
        <span className="wf-mono">2 / 5</span>
      </div>
      <div className="row" style={{ gap: 6 }}>
        {[1, 1, 0, 0, 0].map((d, i) => (
          <div key={i} className="wf-box tight" style={{ flex: 1, height: 14, background: d ? "var(--accent)" : "var(--paper)", boxShadow: "none", padding: 0 }} />
        ))}
      </div>
    </div>
    <div className="col" style={{ gap: 8 }}>
      <div className="wf-box" style={{ padding: "10px 12px", opacity: 0.55 }}>
        <div className="row between">
          <div className="row" style={{ gap: 10 }}>
            <Check />
            <span className="wf-hand hl-strike" style={{ fontSize: 19 }}>Systems Designer · Aurora Works</span>
          </div>
          <span className="wf-chip" style={{ fontSize: 12 }}>liked ✓</span>
        </div>
      </div>
      <div className="wf-box" style={{ padding: "10px 12px", opacity: 0.55 }}>
        <div className="row between">
          <div className="row" style={{ gap: 10 }}>
            <X />
            <span className="wf-hand hl-strike" style={{ fontSize: 19 }}>UI Designer · Bright Hollow</span>
          </div>
          <span className="wf-chip dim" style={{ fontSize: 12 }}>dismissed</span>
        </div>
      </div>
      <div className="wf-box thick" style={{ padding: 14, background: "var(--paper)" }}>
        <div className="wf-mono muted">UP NEXT  ·  3 of 5</div>
        <JobCard studio="HALFLIGHT GAMES" title="Narrative Designer" loc="Remote · World" pay="$70–90k"
          tags={[{ label: "Twine", acc: true }, { label: "Adventure" }, { label: "Senior" }]} variant="flat" />
      </div>
      <div className="wf-box dashed" style={{ padding: "10px 12px", background: "transparent" }}>
        <div className="row between muted">
          <span>4. Combat Designer · Tidewave</span>
          <span className="wf-mono">— locked —</span>
        </div>
      </div>
      <div className="wf-box dashed" style={{ padding: "10px 12px", background: "transparent" }}>
        <div className="row between muted">
          <span>5. Economy Designer · Ember Co</span>
          <span className="wf-mono">— locked —</span>
        </div>
      </div>
    </div>
    <Note top={62} right={20} rotate={-2} arrow="down-left" accent>
      time-boxed.<br />finite. <i>finishable.</i>
    </Note>
    <Note bottom={120} left={2} rotate={-4} arrow="down-right">
      next card stays<br />locked → reduces<br />scroll-anxiety
    </Note>
  </div>
);

Object.assign(window, { FeedList, FeedSwipe, FeedGrid, FeedFocus });
