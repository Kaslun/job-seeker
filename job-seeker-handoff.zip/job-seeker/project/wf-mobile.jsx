// Mobile variants — phone frames

const PhoneFrame = ({ children, label }) => (
  <div style={{
    width: 280, height: 540, margin: "0 auto",
    border: "3px solid var(--ink)", borderRadius: 32,
    boxShadow: "4px 4px 0 0 var(--ink)",
    background: "var(--paper)", overflow: "hidden",
    position: "relative", padding: "16px 14px 14px"
  }}>
    <div style={{ position: "absolute", top: 6, left: "50%", transform: "translateX(-50%)", width: 60, height: 5, background: "var(--ink)", borderRadius: 4 }} />
    {children}
  </div>
);

// ─── Mobile A · swipe ──────────────────────────────────────────────
const MobileSwipe = () => (
  <div className="wf" style={{ padding: 18 }}>
    <PhoneFrame>
      <div className="row between" style={{ marginTop: 8, marginBottom: 8 }}>
        <Logo size={16} />
        <span className="wf-mono dim" style={{ fontSize: 10 }}>12 left</span>
      </div>
      <div style={{ position: "relative", height: 360 }}>
        <div className="stack-card behind-2" />
        <div className="stack-card behind-1" />
        <div className="stack-card" style={{ padding: 12, display: "flex", flexDirection: "column", gap: 6 }}>
          <div className="row between">
            <StudioMark size={36} name="AURORA" />
            <span className="wf-chip accent" style={{ fontSize: 10 }}>95% match</span>
          </div>
          <div className="wf-mono muted" style={{ fontSize: 10 }}>AURORA WORKS</div>
          <div className="wf-hand" style={{ fontSize: 22, fontWeight: 700, lineHeight: 1 }}>Systems Designer</div>
          <div className="row wrap muted" style={{ gap: 6, fontSize: 11 }}><span>📍 Remote EU</span><span>💰 €55–70k</span></div>
          <TagRow tags={[{ label: "Unity", acc: true }, { label: "RPG" }, { label: "Mid" }]} />
          <Lines count={3} widths={["96%", "80%", "60%"]} />
        </div>
      </div>
      <div className="row" style={{ justifyContent: "space-around", marginTop: 12 }}>
        <button className="wf-btn" style={{ width: 44, height: 44, borderRadius: "50%", padding: 0, justifyContent: "center" }}><X size={18} /></button>
        <button className="wf-btn"><Bookmark size={14} /> park</button>
        <button className="wf-btn primary" style={{ width: 44, height: 44, borderRadius: "50%", padding: 0, justifyContent: "center" }}><Heart filled size={18} /></button>
      </div>
    </PhoneFrame>
    <Note top={40} right={6} rotate={-3} arrow="down-left" accent>
      thumb-zone actions:<br />reachable + final
    </Note>
  </div>
);

// ─── Mobile B · feed list ──────────────────────────────────────────
const MobileList = () => (
  <div className="wf" style={{ padding: 18 }}>
    <PhoneFrame>
      <div className="row between" style={{ marginTop: 8, marginBottom: 8 }}>
        <span className="wf-hand" style={{ fontSize: 22, fontWeight: 700 }}>Feed</span>
        <span className="wf-chip" style={{ fontSize: 10 }}>filters ▾</span>
      </div>
      <div className="col" style={{ gap: 6 }}>
        {[
          { s: "AURORA", t: "Systems Designer", g: "RPG" },
          { s: "MOSSGATE", t: "Level Designer", g: "FPS" },
          { s: "HALFLIGHT", t: "Narrative Designer", g: "ADV" },
          { s: "POLARFOX", t: "UX Designer", g: "MOB" },
        ].map((j, i) => (
          <div key={i} className="wf-box" style={{ padding: 8 }}>
            <div className="row between">
              <div className="row" style={{ gap: 8, minWidth: 0 }}>
                <StudioMark size={32} name={j.s.slice(0, 5)} />
                <div style={{ minWidth: 0 }}>
                  <div className="wf-mono muted" style={{ fontSize: 9 }}>{j.s}</div>
                  <div className="wf-hand" style={{ fontSize: 14, fontWeight: 700, lineHeight: 1.05, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{j.t}</div>
                </div>
              </div>
              <div className="row" style={{ gap: 4 }}>
                <button className="wf-btn icon-only" style={{ padding: 4 }}><X size={12} /></button>
                <button className="wf-btn primary icon-only" style={{ padding: 4 }}><Heart filled size={12} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, borderTop: "2px solid var(--ink)", background: "var(--paper)", padding: "6px 12px" }}>
        <div className="row between wf-mono" style={{ fontSize: 10 }}>
          <span className="hl">Feed</span><span className="dim">Saved</span><span className="dim">Applied</span><span className="dim">Me</span>
        </div>
      </div>
    </PhoneFrame>
    <Note top={120} left={6} rotate={3} arrow="down-right">
      swipe-left on row =<br />dismiss too
    </Note>
  </div>
);

// ─── Mobile C · daily 5 ──────────────────────────────────────────
const MobileFocus = () => (
  <div className="wf" style={{ padding: 18 }}>
    <PhoneFrame>
      <div className="row between" style={{ marginTop: 8, marginBottom: 6 }}>
        <span className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Today</span>
        <span className="wf-chip accent" style={{ fontSize: 10 }}>2 / 5</span>
      </div>
      <div className="row" style={{ gap: 4, marginBottom: 8 }}>
        {[1, 1, 0, 0, 0].map((d, i) => (
          <div key={i} style={{ flex: 1, height: 8, background: d ? "var(--accent)" : "var(--paper-2)", border: "1.5px solid var(--ink)", borderRadius: 3 }} />
        ))}
      </div>
      <div className="wf-box thick" style={{ padding: 10, marginTop: 8 }}>
        <div className="wf-mono muted" style={{ fontSize: 9 }}>UP NEXT · 3 of 5</div>
        <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.05 }}>Narrative Designer</div>
        <div className="wf-mono muted" style={{ fontSize: 10 }}>HALFLIGHT GAMES</div>
        <Lines count={2} widths={["94%", "60%"]} />
        <div className="row" style={{ justifyContent: "space-around", marginTop: 8 }}>
          <button className="wf-btn icon-only"><X size={14} /></button>
          <button className="wf-btn"><Bookmark size={11} /> park</button>
          <button className="wf-btn primary icon-only"><Heart filled size={14} /></button>
        </div>
      </div>
      <div className="col" style={{ gap: 4, marginTop: 8 }}>
        <div className="wf-box dashed" style={{ padding: "5px 8px", background: "transparent" }}>
          <div className="row between muted" style={{ fontSize: 11 }}><span>4. Combat · Tidewave</span><span className="wf-mono">locked</span></div>
        </div>
        <div className="wf-box dashed" style={{ padding: "5px 8px", background: "transparent" }}>
          <div className="row between muted" style={{ fontSize: 11 }}><span>5. Economy · Ember</span><span className="wf-mono">locked</span></div>
        </div>
      </div>
      <div className="wf-box fill-accent" style={{ padding: "6px 10px", marginTop: 10, textAlign: "center" }}>
        <span className="wf-hand" style={{ fontSize: 14, fontWeight: 700 }}>finish in 6 min ⏱</span>
      </div>
    </PhoneFrame>
    <Note bottom={40} right={6} rotate={-2} arrow="left" accent>
      "you're almost done"<br />beats infinite scroll
    </Note>
  </div>
);

Object.assign(window, { MobileSwipe, MobileList, MobileFocus });
