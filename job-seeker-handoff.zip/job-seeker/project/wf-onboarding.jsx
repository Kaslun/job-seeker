// Onboarding / preferences setup variants

// ─── A · Wizard with progress ──────────────────────────────────────
const OnboardWizard = () => (
  <div className="wf center" style={{ flexDirection: "column", padding: 30 }}>
    <Logo size={28} />
    <div className="wf-mono muted" style={{ marginTop: 4, marginBottom: 14 }}>STEP 2 / 4</div>
    <div className="row" style={{ gap: 6, marginBottom: 18 }}>
      {[1, 1, 0, 0].map((d, i) => (
        <div key={i} className="wf-box tight" style={{ width: 80, height: 10, background: d ? "var(--accent)" : "var(--paper-2)", boxShadow: "none", padding: 0 }} />
      ))}
    </div>
    <h1 style={{ fontSize: 38, textAlign: "center" }}>What engines feel like home?</h1>
    <div className="muted" style={{ textAlign: "center", marginBottom: 14 }}>Pick all that apply. Skip if it's not your thing.</div>
    <div className="row wrap" style={{ gap: 10, justifyContent: "center", maxWidth: 520 }}>
      {[{ l: "Unity", on: true }, { l: "Unreal", on: true }, { l: "Godot" }, { l: "Custom / proprietary" }, { l: "GameMaker" }, { l: "Roblox" }, { l: "Web (PixiJS, Phaser)" }].map((c, i) => (
        <span key={i} className={"wf-chip" + (c.on ? " accent" : "")} style={{ fontSize: 17, padding: "6px 14px" }}>
          {c.on ? "✓ " : "+ "}{c.l}
        </span>
      ))}
    </div>
    <div className="row" style={{ gap: 10, marginTop: 22 }}>
      <button className="wf-btn">← back</button>
      <button className="wf-btn lg primary">next: genres →</button>
      <button className="wf-btn ghost">skip</button>
    </div>
    <Note top={120} right={30} rotate={-3} arrow="down-left" accent>
      tiny steps. always<br />a "skip" escape hatch.
    </Note>
  </div>
);

// ─── B · One long form, all visible ────────────────────────────────
const OnboardOneShot = () => (
  <div className="wf">
    <div className="row between" style={{ marginBottom: 12 }}>
      <Logo />
      <span className="wf-mono muted">save &amp; come back anytime</span>
    </div>
    <h1 style={{ fontSize: 32 }}>Tell us, in 60 seconds.</h1>
    <div className="muted" style={{ marginBottom: 12 }}>Everything's optional. Edit later from your profile.</div>
    <div className="col" style={{ gap: 10 }}>
      <div className="wf-box">
        <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Roles I'd consider</div>
        <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
          {["Systems", "Level", "Narrative", "Combat", "UX", "Tech", "Economy"].map((r, i) => (
            <span key={i} className={"wf-chip" + (i < 3 ? " accent" : "")}>{i < 3 ? "✓ " : "+ "}{r}</span>
          ))}
        </div>
      </div>
      <div className="wf-box">
        <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Engines</div>
        <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
          {["Unity", "Unreal", "Godot", "Custom", "GameMaker", "Roblox"].map((r, i) => (
            <span key={i} className={"wf-chip" + (i < 2 ? " accent" : "")}>{r}</span>
          ))}
        </div>
      </div>
      <div className="wf-box">
        <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Genres I love</div>
        <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
          {["RPG", "FPS", "Strategy", "Sim", "Adventure", "Roguelike", "Fighting", "Puzzle"].map((r, i) => (
            <span key={i} className={"wf-chip" + ([0, 4, 5].includes(i) ? " accent" : "")}>{r}</span>
          ))}
        </div>
      </div>
      <div className="row" style={{ gap: 10 }}>
        <div className="wf-box grow">
          <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Where</div>
          <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
            {["Remote", "Hybrid", "On-site"].map((r, i) => (
              <span key={i} className={"wf-chip" + (i === 0 ? " accent" : "")}>{r}</span>
            ))}
            <span className="wf-chip dim">+ visa needed</span>
          </div>
        </div>
        <div className="wf-box grow">
          <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>Level</div>
          <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
            {["Junior", "Mid", "Senior", "Lead"].map((r, i) => (
              <span key={i} className={"wf-chip" + (i === 1 ? " accent" : "")}>{r}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
    <div className="row between" style={{ marginTop: 14 }}>
      <span className="wf-mono dim">we'll never share these</span>
      <button className="wf-btn xl primary">show me jobs →</button>
    </div>
    <Note top={70} right={30} rotate={-2} arrow="down" accent>
      one screen, no progress<br />bar = no abandonment guilt
    </Note>
  </div>
);

// ─── C · Conversational ────────────────────────────────────────────
const OnboardChat = () => (
  <div className="wf" style={{ background: "var(--paper)" }}>
    <div className="row between" style={{ marginBottom: 14 }}>
      <Logo />
      <span className="wf-mono dim">close ✕</span>
    </div>
    <div className="col" style={{ gap: 12, maxWidth: 540, margin: "0 auto" }}>
      <div className="wf-box" style={{ alignSelf: "flex-start", maxWidth: "75%" }}>
        <div className="wf-mono muted" style={{ fontSize: 11 }}>QUESTBOARD</div>
        <div style={{ fontSize: 17 }}>Hey 👋 I'll find you 5 game-design jobs by tomorrow. Sound okay?</div>
      </div>
      <div className="wf-box fill-accent" style={{ alignSelf: "flex-end", maxWidth: "60%" }}>
        <div style={{ fontSize: 17 }}>yes lets go</div>
      </div>
      <div className="wf-box" style={{ alignSelf: "flex-start", maxWidth: "75%" }}>
        <div style={{ fontSize: 17 }}>What roles? (tap any — no wrong answers)</div>
        <div className="row wrap" style={{ gap: 6, marginTop: 8 }}>
          {["Systems", "Level", "Narrative", "Combat", "UX", "any"].map((r, i) => (
            <span key={i} className={"wf-chip" + (i === 0 ? " accent" : "")}>{r}</span>
          ))}
        </div>
      </div>
      <div className="wf-box fill-accent" style={{ alignSelf: "flex-end", maxWidth: "60%" }}>
        <div style={{ fontSize: 17 }}>systems &amp; level</div>
      </div>
      <div className="wf-box" style={{ alignSelf: "flex-start", maxWidth: "75%" }}>
        <div style={{ fontSize: 17 }}>Cool. Any engines you'd avoid?</div>
      </div>
      <div className="wf-box dashed" style={{ alignSelf: "flex-end", maxWidth: "70%", background: "transparent" }}>
        <div className="wf-mono dim">typing…</div>
      </div>
    </div>
    <Note bottom={60} right={20} rotate={-3} arrow="down-left" accent>
      conversation = lower<br />executive function load<br />vs. forms
    </Note>
  </div>
);

Object.assign(window, { OnboardWizard, OnboardOneShot, OnboardChat });
