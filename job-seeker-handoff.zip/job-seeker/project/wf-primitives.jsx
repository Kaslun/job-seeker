// Small reusable wireframe primitives — sketchy job cards, annotation arrows, etc.

const Note = ({ children, top, left, right, bottom, rotate = -2, arrow, accent = false }) => (
  <div className={"wf-note" + (accent ? " bg-acc" : "")} style={{ top, left, right, bottom, transform: `rotate(${rotate}deg)` }}>
    {arrow === "down" && <span className="arrow">↓</span>}
    {arrow === "left" && <span className="arrow" style={{ display: "inline-block", marginRight: 6 }}>←</span>}
    {arrow === "up" && <span className="arrow">↑</span>}
    {children}
    {arrow === "down-right" && <span className="arrow" style={{ display: "block", textAlign: "right" }}>↘</span>}
    {arrow === "down-left" && <span className="arrow" style={{ display: "block", textAlign: "left" }}>↙</span>}
  </div>
);

const Lines = ({ count = 3, widths }) => (
  <div className="col" style={{ gap: 6 }}>
    {Array.from({ length: count }).map((_, i) => (
      <div key={i} className="wf-line" style={{ width: (widths && widths[i]) || `${60 + (i * 7) % 35}%` }} />
    ))}
  </div>
);

const Avatar = ({ size = 36, label = "GS" }) => (
  <div className="wf-avatar" style={{ width: size, height: size, fontSize: size * 0.45 }}>{label}</div>
);

const StudioMark = ({ size = 56, name = "STUDIO" }) => (
  <div className="wf-img" style={{ width: size, height: size, fontSize: 9, padding: 0 }}>
    <span style={{ background: "var(--paper)", padding: "1px 4px", border: "1.5px solid var(--ink-2)", borderRadius: 4 }}>{name}</span>
  </div>
);

// A pretend logo wordmark for the product
const Logo = ({ size = 22 }) => (
  <div className="row" style={{ gap: 6 }}>
    <div className="wf-circle" style={{ width: size, height: size, background: "var(--accent)", fontFamily: "Caveat", fontWeight: 700, fontSize: size * 0.7 }}>q</div>
    <span className="wf-hand" style={{ fontSize: size, fontWeight: 700 }}>questboard</span>
  </div>
);

// Little hand-drawn icon helpers (kept simple)
const Heart = ({ filled = false, size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: "block" }}>
    <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" fill={filled ? "var(--accent)" : "none"} stroke="var(--ink)" strokeWidth="1.8" strokeLinejoin="round" />
  </svg>
);
const X = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24"><path d="M5 5l14 14M19 5L5 19" stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" /></svg>
);
const Check = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24"><path d="M4 12l5 5L20 6" stroke="var(--ink)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>
);
const Bookmark = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24"><path d="M6 4h12v17l-6-4-6 4z" stroke="var(--ink)" strokeWidth="1.8" fill="none" strokeLinejoin="round" /></svg>
);

// "App chrome" — top nav used inside desktop wireframes
const Chrome = ({ active = "Feed", showStreak = true }) => (
  <div className="row between" style={{ marginBottom: 14 }}>
    <Logo />
    <div className="row" style={{ gap: 14 }}>
      {["Feed", "Saved", "Applied", "Profile"].map(n => (
        <span key={n} className={n === active ? "u-draw" : "muted"} style={{ fontSize: 16 }}>{n}</span>
      ))}
    </div>
    {showStreak ? (
      <div className="wf-chip accent" title="dopamine">🔥 3-day streak</div>
    ) : <div style={{ width: 80 }} />}
  </div>
);

// Tag row used everywhere
const TagRow = ({ tags = [] }) => (
  <div className="row wrap" style={{ gap: 6 }}>
    {tags.map((t, i) => (
      <span key={i} className={"wf-chip" + (t.acc ? " accent" : "") + (t.dim ? " dim" : "")}>{t.label || t}</span>
    ))}
  </div>
);

// Like / Dislike button pair — the core mechanic
const LikeDislike = ({ size = "md", vertical = false }) => {
  const big = size === "xl";
  const dim = big ? 64 : size === "lg" ? 52 : 40;
  return (
    <div className={vertical ? "col" : "row"} style={{ gap: 10 }}>
      <button className="wf-btn" title="Not for me — remove forever" style={{ width: dim, height: dim, padding: 0, justifyContent: "center", borderRadius: "50%" }}>
        <X size={big ? 28 : 20} />
      </button>
      <button className="wf-btn primary" title="Looks good — keep" style={{ width: dim, height: dim, padding: 0, justifyContent: "center", borderRadius: "50%" }}>
        <Heart filled size={big ? 28 : 20} />
      </button>
    </div>
  );
};

// Job card — the standard listing block
const JobCard = ({
  studio = "AURORA WORKS",
  title = "Systems Designer",
  loc = "Remote · EU",
  pay = "€55–70k",
  tags = [{ label: "Unity" }, { label: "RPG" }, { label: "Mid" }],
  blurb = true,
  variant = "default", // 'default' | 'flat' | 'compact'
  showActions = true,
}) => (
  <div className={"wf-box" + (variant === "flat" ? " flush" : "")} style={{ padding: variant === "compact" ? "10px 12px" : "14px 16px" }}>
    <div className="row" style={{ alignItems: "flex-start", gap: 12 }}>
      <StudioMark size={variant === "compact" ? 40 : 52} name={studio.split(" ")[0].slice(0, 6)} />
      <div className="grow">
        <div className="row between" style={{ alignItems: "flex-start" }}>
          <div>
            <div className="wf-mono muted" style={{ letterSpacing: 1 }}>{studio}</div>
            <div className="wf-hand" style={{ fontSize: variant === "compact" ? 22 : 26, fontWeight: 700, lineHeight: 1.05 }}>{title}</div>
          </div>
          {showActions && <LikeDislike />}
        </div>
        <div className="row wrap" style={{ gap: 8, marginTop: 6, fontSize: 14 }}>
          <span className="muted">📍 {loc}</span>
          <span className="muted">💰 {pay}</span>
        </div>
        {blurb && <div style={{ marginTop: 8 }}><Lines count={2} widths={["94%", "70%"]} /></div>}
        <div style={{ marginTop: 10 }}><TagRow tags={tags} /></div>
      </div>
    </div>
  </div>
);

Object.assign(window, { Note, Lines, Avatar, StudioMark, Logo, Heart, X, Check, Bookmark, Chrome, TagRow, LikeDislike, JobCard });
