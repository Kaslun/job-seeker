// Saved jobs + applications tracker variants

// ─── A · Saved (kanban-ish columns) ───────────────────────────────
const SavedColumns = () => (
  <div className="wf">
    <Chrome active="Saved" />
    <div className="row between" style={{ marginBottom: 10 }}>
      <h1>Your pile</h1>
      <span className="wf-chip accent">14 saved · 5 expiring this week</span>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
      {[
        { title: "Liked", count: 8, accent: true, items: [
          { s: "AURORA", t: "Systems Designer" },
          { s: "MOSSGATE", t: "Level Designer" },
          { s: "HALFLIGHT", t: "Narrative Designer" },
        ] },
        { title: "Parked", count: 4, items: [
          { s: "POLARFOX", t: "UX Designer" },
          { s: "TIDEWAVE", t: "Combat Designer" },
        ] },
        { title: "Drafting", count: 2, items: [
          { s: "EMBER CO", t: "Economy Designer" },
        ] },
      ].map((col, i) => (
        <div key={i} className={"wf-box" + (col.accent ? " fill-accent" : " fill-paper2")} style={{ padding: 10, minHeight: 360 }}>
          <div className="row between" style={{ marginBottom: 8 }}>
            <span className="wf-hand" style={{ fontSize: 22, fontWeight: 700 }}>{col.title}</span>
            <span className="wf-mono">{col.count}</span>
          </div>
          <div className="col" style={{ gap: 8 }}>
            {col.items.map((it, j) => (
              <div key={j} className="wf-box" style={{ padding: "8px 10px", background: "var(--paper)" }}>
                <div className="wf-mono muted" style={{ fontSize: 10 }}>{it.s}</div>
                <div className="wf-hand" style={{ fontSize: 17, fontWeight: 700 }}>{it.t}</div>
                <div className="row between" style={{ marginTop: 4 }}>
                  <span className="wf-mono dim">⏰ 4d left</span>
                  <span className="wf-mono dim">⋮</span>
                </div>
              </div>
            ))}
            <div className="wf-box dashed" style={{ padding: "12px", textAlign: "center", color: "var(--ink-3)", background: "transparent" }}>+ drop here</div>
          </div>
        </div>
      ))}
    </div>
    <Note top={50} right={20} rotate={-2} arrow="down" accent>
      "expiring" nudge<br />without nagging
    </Note>
    <Note bottom={20} left={10} rotate={-3} arrow="up-right">
      drag between columns →<br />tactile = dopamine
    </Note>
  </div>
);

// ─── B · Applications tracker (timeline) ──────────────────────────
const Tracker = () => (
  <div className="wf">
    <Chrome active="Applied" />
    <div className="row between" style={{ marginBottom: 10 }}>
      <h1>Applications</h1>
      <div className="row" style={{ gap: 6 }}>
        <span className="wf-chip">All ▾</span>
        <span className="wf-chip accent">5 awaiting reply</span>
      </div>
    </div>
    <div className="wf-box fill-paper2" style={{ marginBottom: 12, padding: 12 }}>
      <div className="row between">
        <div>
          <div className="wf-hand" style={{ fontSize: 22, fontWeight: 700 }}>this week</div>
          <div className="muted" style={{ fontSize: 14 }}>3 applied · 1 reply · 1 interview booked</div>
        </div>
        <div className="row" style={{ gap: 4 }}>
          {[1, 1, 1, 0, 0, 0, 0].map((d, i) => (
            <div key={i} className="wf-box tight" style={{ width: 26, height: 26, padding: 0, background: d ? "var(--accent)" : "var(--paper)", boxShadow: "none", textAlign: "center", fontSize: 11, lineHeight: "26px" }}>{["m","t","w","t","f","s","s"][i]}</div>
          ))}
        </div>
      </div>
    </div>
    <div className="col" style={{ gap: 8 }}>
      {[
        { s: "AURORA", t: "Systems Designer", stage: "Interview", st: "ok", date: "Tue 14:00" },
        { s: "MOSSGATE", t: "Level Designer", stage: "Replied", st: "acc", date: "Yesterday" },
        { s: "HALFLIGHT", t: "Narrative Designer", stage: "Sent", st: "", date: "3 days ago" },
        { s: "POLARFOX", t: "UX Designer", stage: "Sent", st: "", date: "1 week ago" },
        { s: "BRIGHT HOLLOW", t: "UI Designer", stage: "Rejected", st: "no", date: "2 weeks ago" },
      ].map((row, i) => (
        <div key={i} className="wf-box" style={{ padding: "10px 12px" }}>
          <div className="row between">
            <div className="row" style={{ gap: 12 }}>
              <StudioMark size={36} name={row.s.slice(0, 5)} />
              <div>
                <div className="wf-mono muted" style={{ fontSize: 10 }}>{row.s}</div>
                <div className="wf-hand" style={{ fontSize: 19, fontWeight: 700 }}>{row.t}</div>
              </div>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <span className={"pill" + (row.st ? " " + row.st : "")}>{row.stage}</span>
              <span className="wf-mono dim" style={{ minWidth: 90, textAlign: "right" }}>{row.date}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
    <Note top={150} right={20} rotate={-2} arrow="down-left" accent>
      week strip = visible<br />proof of progress.<br /><i>essential for adhd.</i>
    </Note>
    <Note bottom={20} left={6} rotate={2} arrow="up">
      no "ghosted" status — just<br />date drift. less self-blame.
    </Note>
  </div>
);

// ─── C · Single application detail ────────────────────────────────
const ApplicationDetail = () => (
  <div className="wf">
    <Chrome active="Applied" />
    <span className="wf-mono muted">← all applications</span>
    <div className="row between" style={{ marginTop: 8, marginBottom: 12 }}>
      <div className="row" style={{ gap: 12 }}>
        <StudioMark size={56} name="AURORA" />
        <div>
          <div className="wf-mono muted" style={{ letterSpacing: 1 }}>AURORA WORKS</div>
          <h1 style={{ fontSize: 30 }}>Systems Designer</h1>
        </div>
      </div>
      <span className="pill ok" style={{ fontSize: 14, padding: "3px 12px" }}>Interview booked</span>
    </div>
    <div className="wf-divider" style={{ marginBottom: 12 }} />
    <div className="row" style={{ gap: 18, alignItems: "stretch" }}>
      <div className="grow">
        <div className="wf-hand" style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>timeline</div>
        <div className="col" style={{ gap: 8, position: "relative", paddingLeft: 18, borderLeft: "2px dashed var(--ink-2)", marginLeft: 8 }}>
          {[
            { d: "Mar 12", t: "applied", note: "cover letter v3 + portfolio" },
            { d: "Mar 14", t: "auto-reply received", note: "" },
            { d: "Mar 18", t: "recruiter screen booked", note: "30 min · Tuesday 14:00 CET" },
            { d: "Mar 21", t: "next: take-home (est 4h)", note: "due Mar 28", up: true },
          ].map((s, i) => (
            <div key={i} className="row" style={{ gap: 10, alignItems: "flex-start" }}>
              <div className="wf-circle" style={{ width: 14, height: 14, position: "absolute", left: -8, marginTop: 6, background: s.up ? "var(--accent)" : "var(--paper)" }} />
              <div>
                <div className="wf-mono muted">{s.d}</div>
                <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>{s.t}</div>
                {s.note && <div className="muted" style={{ fontSize: 13 }}>{s.note}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="col" style={{ width: 240, gap: 10 }}>
        <div className="wf-box fill-accent">
          <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>next step</div>
          <div style={{ fontSize: 14 }}>Take-home, 4h, due Mar 28.</div>
          <button className="wf-btn" style={{ marginTop: 6, width: "100%", justifyContent: "center" }}>break into 30m chunks</button>
        </div>
        <div className="wf-box">
          <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>your notes</div>
          <Lines count={3} widths={["94%", "80%", "60%"]} />
        </div>
        <div className="wf-box dashed" style={{ background: "transparent" }}>
          <div className="wf-mono muted">FILES</div>
          <div className="wf-mono">cover_v3.pdf<br />portfolio_2026.pdf</div>
        </div>
      </div>
    </div>
    <Note top={140} right={30} rotate={-3} arrow="down" accent>
      "break into chunks"<br />button = adhd magic
    </Note>
  </div>
);

Object.assign(window, { SavedColumns, Tracker, ApplicationDetail });
