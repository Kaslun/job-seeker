// v2 — consolidated chosen direction.
// Feed = list (A) + focus/streak/progress (D), with swipe-out on like/dislike.

const V2_JOBS = [
  { id: "j1", studio: "AURORA WORKS", title: "Systems Designer", loc: "Remote · EU", pay: "€55–70k", tags: [{ label: "Unity", acc: true }, { label: "RPG" }, { label: "Mid level" }] },
  { id: "j2", studio: "MOSSGATE STUDIO", title: "Level Designer", loc: "Hybrid · Berlin", pay: "€48–60k", tags: [{ label: "Unreal" }, { label: "FPS" }, { label: "2 yrs+" }] },
  { id: "j3", studio: "HALFLIGHT GAMES", title: "Narrative Designer", loc: "Remote · World", pay: "$70–90k", tags: [{ label: "Twine" }, { label: "Adventure", acc: true }, { label: "Senior" }] },
  { id: "j4", studio: "POLARFOX", title: "UX Designer", loc: "Remote · EU", pay: "€50–62k", tags: [{ label: "Mobile" }, { label: "F2P" }, { label: "Mid" }] },
  { id: "j5", studio: "TIDEWAVE", title: "Combat Designer", loc: "Onsite · Helsinki", pay: "€60–80k", tags: [{ label: "Unreal", acc: true }, { label: "Action" }, { label: "Senior" }] },
];

const FeedV2 = () => {
  const [jobs, setJobs] = React.useState(V2_JOBS);
  const [exiting, setExiting] = React.useState({}); // id -> 'left' | 'right'
  const [done, setDone] = React.useState(2); // pre-set "today's progress"

  const decide = (id, dir) => {
    if (exiting[id]) return;
    setExiting(e => ({ ...e, [id]: dir }));
    setTimeout(() => {
      setJobs(js => js.filter(j => j.id !== id));
      setDone(d => Math.min(5, d + 1));
    }, 380);
  };

  return (
    <div className="wf">
      <Chrome active="Feed" />
      <div className="row between" style={{ marginBottom: 8 }}>
        <h1>Today's roles</h1>
        <div className="wf-chip accent">🔥 3-day streak</div>
      </div>
      <div className="wf-box fill-paper2" style={{ padding: 10, marginBottom: 10 }}>
        <div className="row between" style={{ marginBottom: 6 }}>
          <span className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>daily 5</span>
          <span className="wf-mono">{done} / 5</span>
        </div>
        <div className="row" style={{ gap: 6 }}>
          {[0, 1, 2, 3, 4].map(i => (
            <div key={i} className="wf-box tight" style={{ flex: 1, height: 12, background: i < done ? "var(--accent)" : "var(--paper)", boxShadow: "none", padding: 0 }} />
          ))}
        </div>
      </div>

      <div className="col" style={{ gap: 10, position: "relative" }}>
        {jobs.slice(0, 4).map(j => {
          const ex = exiting[j.id];
          const style = ex
            ? { transform: `translateX(${ex === "right" ? 700 : -700}px) rotate(${ex === "right" ? 6 : -6}deg)`, opacity: 0, transition: "transform .38s cubic-bezier(.5,.05,.7,.2), opacity .38s" }
            : { transition: "transform .38s, opacity .38s" };
          return (
            <div key={j.id} style={style}>
              <div className="wf-box" style={{ padding: "12px 14px" }}>
                <div className="row" style={{ alignItems: "flex-start", gap: 12 }}>
                  <StudioMark size={48} name={j.studio.split(" ")[0].slice(0, 6)} />
                  <div className="grow">
                    <div className="row between" style={{ alignItems: "flex-start" }}>
                      <div>
                        <div className="wf-mono muted" style={{ letterSpacing: 1, fontSize: 11 }}>{j.studio}</div>
                        <div className="wf-hand" style={{ fontSize: 24, fontWeight: 700, lineHeight: 1.05 }}>{j.title}</div>
                      </div>
                      <div className="row" style={{ gap: 8 }}>
                        <button className="wf-btn" onClick={() => decide(j.id, "left")}
                          title="dismiss → slides left, gone forever"
                          style={{ width: 40, height: 40, borderRadius: "50%", padding: 0, justifyContent: "center" }}>
                          <X size={18} />
                        </button>
                        <button className="wf-btn primary" onClick={() => decide(j.id, "right")}
                          title="like → slides right, saved"
                          style={{ width: 40, height: 40, borderRadius: "50%", padding: 0, justifyContent: "center" }}>
                          <Heart filled size={18} />
                        </button>
                      </div>
                    </div>
                    <div className="row wrap" style={{ gap: 8, marginTop: 4, fontSize: 13 }}>
                      <span className="muted">📍 {j.loc}</span>
                      <span className="muted">💰 {j.pay}</span>
                    </div>
                    <div style={{ marginTop: 8 }}><TagRow tags={j.tags} /></div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {jobs.length === 0 && (
          <div className="wf-box thick fill-accent center" style={{ padding: 24, flexDirection: "column", textAlign: "center" }}>
            <div className="wf-hand" style={{ fontSize: 30, fontWeight: 700 }}>done for today 🎉</div>
            <div className="muted">come back tomorrow for 5 fresh roles.</div>
          </div>
        )}
      </div>

      <Note top={62} right={20} rotate={-3} arrow="down" accent>
        ✕ slides ← (gone)<br />♥ slides → (saved)<br />try clicking!
      </Note>
      <Note top={170} left={6} rotate={-2} arrow="down-right">
        streak + progress = the<br />daily-loop dopamine
      </Note>
    </div>
  );
};

// Detail = classic two-column (refined slightly).
const DetailV2 = () => <DetailClassic />;

// Onboarding = wizard.
const OnboardV2 = () => <OnboardWizard />;

// Mobile = swipe.
const MobileV2 = () => <MobileSwipe />;

// Tracker — list overview (B), now with stage chips reflecting interview phases.
const STAGES = ["Applied", "Screen", "Take-home", "Interview", "Offer"];

const StageStrip = ({ current, rejected = false }) => {
  const idx = STAGES.indexOf(current);
  return (
    <div className="row" style={{ gap: 4 }}>
      {STAGES.map((s, i) => {
        const active = !rejected && i === idx;
        const done = !rejected && i < idx;
        return (
          <div key={s} className="row" style={{ gap: 4, alignItems: "center" }}>
            <div className="wf-circle" style={{
              width: 14, height: 14,
              background: rejected ? "var(--paper-2)" : active ? "var(--accent)" : done ? "var(--ink)" : "var(--paper)",
              borderColor: rejected ? "var(--ink-3)" : "var(--ink)",
            }} />
            {i < STAGES.length - 1 && <div style={{ width: 18, height: 0, borderTop: `2px ${done ? "solid" : "dashed"} ${rejected ? "var(--ink-3)" : "var(--ink-2)"}` }} />}
          </div>
        );
      })}
    </div>
  );
};

const TrackerV2 = () => {
  const rows = [
    { s: "AURORA", t: "Systems Designer", stage: "Interview", date: "Tue 14:00" },
    { s: "MOSSGATE", t: "Level Designer", stage: "Take-home", date: "due Mar 28" },
    { s: "HALFLIGHT", t: "Narrative Designer", stage: "Screen", date: "yesterday" },
    { s: "POLARFOX", t: "UX Designer", stage: "Applied", date: "1 week ago" },
    { s: "BRIGHT HOLLOW", t: "UI Designer", stage: "Applied", date: "2 wks ago", rejected: true },
  ];
  return (
    <div className="wf">
      <Chrome active="Applied" />
      <div className="row between" style={{ marginBottom: 10 }}>
        <h1>Applications</h1>
        <div className="row" style={{ gap: 6 }}>
          <span className="wf-chip">All ▾</span>
          <span className="wf-chip accent">2 awaiting reply</span>
        </div>
      </div>
      <div className="wf-box fill-paper2" style={{ marginBottom: 10, padding: 10 }}>
        <div className="row between">
          <div>
            <div className="wf-hand" style={{ fontSize: 20, fontWeight: 700 }}>this week</div>
            <div className="muted" style={{ fontSize: 13 }}>3 applied · 1 reply · 1 interview booked</div>
          </div>
          <div className="row" style={{ gap: 4 }}>
            {[1, 1, 1, 0, 0, 0, 0].map((d, i) => (
              <div key={i} className="wf-box tight" style={{ width: 24, height: 24, padding: 0, background: d ? "var(--accent)" : "var(--paper)", boxShadow: "none", textAlign: "center", fontSize: 11, lineHeight: "24px" }}>{["m","t","w","t","f","s","s"][i]}</div>
            ))}
          </div>
        </div>
      </div>
      <div className="col" style={{ gap: 8 }}>
        {rows.map((r, i) => (
          <div key={i} className="wf-box" style={{ padding: "8px 12px", opacity: r.rejected ? 0.55 : 1 }}>
            <div className="row between">
              <div className="row" style={{ gap: 10, minWidth: 0, flex: 1 }}>
                <StudioMark size={32} name={r.s.slice(0, 5)} />
                <div style={{ minWidth: 0 }}>
                  <div className="wf-mono muted" style={{ fontSize: 10 }}>{r.s}</div>
                  <div className="wf-hand" style={{ fontSize: 17, fontWeight: 700, lineHeight: 1.05 }}>{r.t}</div>
                </div>
              </div>
              <div className="col" style={{ alignItems: "flex-end", gap: 4 }}>
                <StageStrip current={r.stage} rejected={r.rejected} />
                <div className="row" style={{ gap: 8 }}>
                  <span className="wf-mono dim" style={{ fontSize: 11 }}>{r.date}</span>
                  {r.rejected
                    ? <span className="pill no" style={{ fontSize: 11 }}>not moving forward</span>
                    : <span className={"pill" + (r.stage === "Interview" ? " ok" : r.stage === "Applied" ? "" : " acc")} style={{ fontSize: 11 }}>{r.stage}</span>}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <Note top={170} right={20} rotate={-2} arrow="down-left" accent>
        stage strip = at-a-glance<br />"where am I?" for every job
      </Note>
    </div>
  );
};

// Single application — extended with interview stage progression.
const ApplicationV2 = () => (
  <div className="wf">
    <Chrome active="Applied" />
    <span className="wf-mono muted">← all applications</span>
    <div className="row between" style={{ marginTop: 8, marginBottom: 8 }}>
      <div className="row" style={{ gap: 12 }}>
        <StudioMark size={56} name="AURORA" />
        <div>
          <div className="wf-mono muted" style={{ letterSpacing: 1 }}>AURORA WORKS</div>
          <h1 style={{ fontSize: 28 }}>Systems Designer</h1>
        </div>
      </div>
      <span className="pill ok" style={{ fontSize: 14, padding: "3px 12px" }}>Interview booked</span>
    </div>

    {/* Big interview stepper */}
    <div className="wf-box fill-paper2" style={{ padding: 14, marginBottom: 12 }}>
      <div className="row between" style={{ marginBottom: 8 }}>
        <div className="wf-hand" style={{ fontSize: 18, fontWeight: 700 }}>where you are</div>
        <span className="wf-mono muted">stage 4 of 5</span>
      </div>
      <div className="row" style={{ gap: 0, alignItems: "center" }}>
        {STAGES.map((s, i) => {
          const idx = 3; // Interview
          const active = i === idx, done = i < idx;
          return (
            <React.Fragment key={s}>
              <div className="col" style={{ alignItems: "center", flex: "0 0 auto", gap: 4 }}>
                <div className="wf-circle" style={{
                  width: 32, height: 32,
                  background: active ? "var(--accent)" : done ? "var(--ink)" : "var(--paper)",
                  color: done ? "var(--paper)" : "var(--ink)",
                  fontFamily: "Caveat", fontWeight: 700, fontSize: 16,
                }}>{done ? "✓" : i + 1}</div>
                <div className="wf-mono" style={{ fontSize: 11, color: active ? "var(--ink)" : done ? "var(--ink-2)" : "var(--ink-3)" }}>{s}</div>
              </div>
              {i < STAGES.length - 1 && (
                <div style={{ flex: 1, height: 0, borderTop: `2px ${done ? "solid" : "dashed"} var(--ink-2)`, marginBottom: 16 }} />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>

    <div className="row" style={{ gap: 14, alignItems: "stretch" }}>
      <div className="grow">
        <div className="wf-hand" style={{ fontSize: 20, fontWeight: 700, marginBottom: 6 }}>timeline</div>
        <div className="col" style={{ gap: 6, position: "relative", paddingLeft: 16, borderLeft: "2px dashed var(--ink-2)", marginLeft: 6 }}>
          {[
            { d: "Mar 12", t: "applied", note: "cover letter v3 + portfolio" },
            { d: "Mar 14", t: "auto-reply", note: "" },
            { d: "Mar 16", t: "recruiter screen ✓", note: "30 min · Mara H." },
            { d: "Mar 21", t: "take-home submitted ✓", note: "4h · economy tuning" },
            { d: "Apr 02", t: "panel interview booked", note: "Tue 14:00 · 90 min · 3 people", up: true },
          ].map((s, i) => (
            <div key={i} className="row" style={{ gap: 10, alignItems: "flex-start", position: "relative" }}>
              <div className="wf-circle" style={{ width: 12, height: 12, position: "absolute", left: -22, marginTop: 6, background: s.up ? "var(--accent)" : "var(--paper)" }} />
              <div>
                <div className="wf-mono muted" style={{ fontSize: 11 }}>{s.d}</div>
                <div className="wf-hand" style={{ fontSize: 17, fontWeight: 700, lineHeight: 1.05 }}>{s.t}</div>
                {s.note && <div className="muted" style={{ fontSize: 12 }}>{s.note}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="col" style={{ width: 220, gap: 8 }}>
        <div className="wf-box fill-accent">
          <div className="wf-hand" style={{ fontSize: 16, fontWeight: 700 }}>next: panel</div>
          <div style={{ fontSize: 13 }}>Tue 14:00 · 90 min · with Mara, Liam, Priya</div>
          <button className="wf-btn" style={{ marginTop: 6, width: "100%", justifyContent: "center", fontSize: 13 }}>add to calendar</button>
          <button className="wf-btn ghost" style={{ marginTop: 4, width: "100%", justifyContent: "center", fontSize: 13 }}>prep checklist</button>
        </div>
        <div className="wf-box">
          <div className="wf-hand" style={{ fontSize: 16, fontWeight: 700 }}>your notes</div>
          <Lines count={3} widths={["94%", "80%", "60%"]} />
        </div>
        <div className="wf-box dashed" style={{ background: "transparent" }}>
          <div className="wf-mono muted" style={{ fontSize: 11 }}>FILES</div>
          <div className="wf-mono" style={{ fontSize: 12 }}>cover_v3.pdf<br />takehome.zip</div>
        </div>
      </div>
    </div>
    <Note top={150} right={26} rotate={-3} arrow="down" accent>
      stepper across the top =<br />the answer to "wait, what<br />was the next step again?"
    </Note>
  </div>
);

Object.assign(window, { FeedV2, DetailV2, OnboardV2, MobileV2, TrackerV2, ApplicationV2, StageStrip });
